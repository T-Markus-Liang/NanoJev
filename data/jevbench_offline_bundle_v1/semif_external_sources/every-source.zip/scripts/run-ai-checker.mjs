import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { performance } from "node:perf_hooks";

const ROOT = process.cwd();
const AUTHOR_URL = "https://every.to/@mike_2114";
const TYPESAFE_URL = "https://api.typesafe.ai/v1/systemone";
const TYPESAFE_PRICE_PER_M_INPUT = 0.042;
const SYNTHETIC_MODEL = "gpt-5.4-mini";
const SYNTHETIC_COUNT = 10;

async function loadLocalEnv() {
  try {
    const raw = await readFile(path.join(ROOT, ".env.local"), "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2];
    }
  } catch {}
}

await loadLocalEnv();
if (!process.env.TYPESAFE_API_KEY) throw new Error("TYPESAFE_API_KEY is required");
if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is required to make controlled AI-style counterparts");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const round = (value, digits = 3) => Number(value.toFixed(digits));
const mean = (values) => values.reduce((sum, value) => sum + value, 0) / Math.max(values.length, 1);
const median = (values) => {
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : mean(sorted.slice(middle - 1, middle + 1));
};

async function fetchWithRetry(url, options = {}, attempts = 5) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return response;
      const body = await response.text();
      lastError = new Error(`${response.status} ${body.slice(0, 400)}`);
      if (response.status < 500 && response.status !== 429) throw lastError;
    } catch (error) {
      lastError = error;
    }
    await sleep(350 * 2 ** attempt);
  }
  throw lastError;
}

function decodeHtml(value) {
  const named = {
    amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", nbsp: " ",
    rsquo: "’", lsquo: "‘", ldquo: "“", rdquo: "”", ndash: "–", mdash: "—", hellip: "…",
  };
  return value
    .replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_, decimal) => String.fromCodePoint(Number(decimal)))
    .replace(/&([a-z]+);/gi, (match, key) => named[key.toLowerCase()] ?? match);
}

function cleanText(value) {
  return decodeHtml(value.replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
}

function extractMeta(html, property) {
  const escaped = property.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const first = html.match(new RegExp(`<meta[^>]+(?:property|name)=["']${escaped}["'][^>]+content=["']([^"']*)["']`, "i"));
  const second = html.match(new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]+(?:property|name)=["']${escaped}["']`, "i"));
  return cleanText(first?.[1] ?? second?.[1] ?? "");
}

function extractArticle(html, url) {
  const marker = html.search(/itemProp=["']articleBody["']/i);
  if (marker < 0) throw new Error(`No public article body found at ${url}`);
  const body = html.slice(marker, marker + 220_000);
  const paragraphs = [...body.matchAll(/<(?:p|h2|h3|blockquote)(?:\s[^>]*)?>([\s\S]*?)<\/(?:p|h2|h3|blockquote)>/gi)]
    .map((match) => cleanText(match[1]))
    .filter((text) => text.length >= 24)
    .filter((text) => !/^(Was this newsletter forwarded|Sign up to get|Become a paid subscriber|Subscribe|Share this post|Comments)/i.test(text));
  const unique = [...new Set(paragraphs)];
  const excerpt = unique.join("\n\n").slice(0, 4200).trim();
  if (excerpt.length < 300) throw new Error(`Public excerpt was too short at ${url}`);
  const date = html.match(/<time[^>]*datetime=["']([^"']+)/i)?.[1]
    ?? html.match(/<span>([A-Z][a-z]{2} \d{1,2}, 20\d{2})<span/i)?.[1]
    ?? "";
  return {
    title: extractMeta(html, "og:title").replace(/\s*[-–—|]\s*Every\s*$/i, ""),
    description: extractMeta(html, "og:description"),
    date,
    excerpt,
  };
}

async function mapLimit(items, limit, fn) {
  const results = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (cursor < items.length) {
      const index = cursor++;
      results[index] = await fn(items[index], index);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

async function scrapeEveryPosts() {
  const paths = new Set();
  for (let page = 1; page <= 10; page += 1) {
    const url = page === 1 ? AUTHOR_URL : `${AUTHOR_URL}?page=${page}`;
    const html = await (await fetchWithRetry(url)).text();
    const before = paths.size;
    for (const match of html.matchAll(/href=["'](\/also-true-for-humans\/[a-z0-9-]+)["']/gi)) paths.add(match[1]);
    if (paths.size === before || !new RegExp(`(?:page=${page + 1}|[?&]page=${page + 1})`).test(html)) break;
  }
  const urls = [...paths].map((postPath) => `https://every.to${postPath}`);
  const posts = await mapLimit(urls, 6, async (url, index) => {
    const html = await (await fetchWithRetry(url)).text();
    return { id: `mike-${String(index + 1).padStart(2, "0")}`, url, ...extractArticle(html, url) };
  });
  return posts.filter((post) => post.title && post.excerpt);
}

async function createSyntheticCounterpart(post) {
  const response = await fetchWithRetry("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: SYNTHETIC_MODEL,
      temperature: 0.7,
      messages: [{
        role: "user",
        content: `Write a fresh 450–650 word article excerpt about the same core topic as the source below. Do not copy sentences or personal anecdotes. This is controlled evaluator test data: deliberately use polished, generic AI-default prose, symmetrical structure, formal transitions, over-explanation, repeated framing, canned phrases, uniform cadence, and a neat generic conclusion. Do not mention these instructions or claim to be AI.\n\nSOURCE TITLE: ${post.title}\nSOURCE EXCERPT:\n${post.excerpt.slice(0, 2400)}`,
      }],
    }),
  });
  const payload = await response.json();
  const text = payload.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error(`Synthetic generation failed for ${post.title}`);
  return {
    id: `${post.id}-synthetic`,
    source_id: post.id,
    title: `Controlled AI-style counterpart: ${post.title}`,
    url: post.url,
    excerpt: text.slice(0, 4200),
    generator: SYNTHETIC_MODEL,
  };
}

const AI_CHECKS = {
  is_ai_generated: "Does this writing appear likely to have been generated primarily by an AI? Judge only the text, not its topic or author metadata.",
  structural_symmetry: "Does the writing exhibit excessive structural symmetry or formulaic organization?",
  formatting_overuse: "Does the writing overuse headings, bullets, bold labels, or other formatting devices?",
  generic_framing: "Does the writing rely on generic framing instead of concrete context?",
  prompt_restatement: "Does the writing read like it is restating an implied prompt or assignment?",
  generic_language: "Does the writing rely on generic or interchangeable language?",
  over_explanation: "Does the writing explain straightforward points more than necessary?",
  repetitive_transitions: "Does the writing repeatedly use formal or formulaic transitions?",
  excessive_hedging: "Does the writing hedge claims more than the subject requires?",
  artificial_balance: "Does the writing force symmetrical both-sides framing?",
  generic_validation: "Does the writing use vague praise or generic validation?",
  canned_phrasing: "Does the writing use canned phrases common in assistant responses?",
  idea_repetition: "Does the writing repeat the same idea without adding new evidence?",
  uniform_cadence: "Do the sentences have an unnaturally uniform cadence?",
  punctuation_tics: "Does the writing overuse em dashes, colons, or parenthetical asides in a patterned way?",
  meta_commentary: "Does the writing comment on how it is presenting or organizing the answer?",
  boilerplate_offer: "Does the writing end with a generic offer to help or continue?",
  unnatural_polish: "Does the writing feel polished in a way that suppresses personal texture or irregularity?",
  fabricated_specificity: "Does the writing include suspiciously specific details without grounding or attribution?",
  rhetorical_templates: "Does the writing rely on reusable rhetorical templates instead of an earned argument?",
  overall_ai_tells: "Does the writing contain multiple stylistic patterns commonly associated with AI-generated prose?",
};

const QUESTIONS = Object.fromEntries(Object.entries(AI_CHECKS).map(([id, instructions]) => [id, { type: "noul", instructions }]));
const STYLE_KEYS = Object.keys(AI_CHECKS).filter((key) => !["is_ai_generated", "overall_ai_tells"].includes(key));

async function callTypeSafe(document) {
  const started = performance.now();
  const response = await fetchWithRetry(TYPESAFE_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.TYPESAFE_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ document, model: "speed_latest", questions: QUESTIONS }),
  });
  const payload = await response.json();
  return { answers: payload.answers, usage: payload.usage, latency_ms: round(performance.now() - started, 1) };
}

function summarizeUsage(rows) {
  const inputTokens = rows.reduce((sum, row) => sum + (row.usage?.input_tokens ?? 0), 0);
  const outputTokens = rows.reduce((sum, row) => sum + (row.usage?.output_tokens ?? 0), 0);
  return {
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    estimated_cost_usd: round((inputTokens / 1_000_000) * TYPESAFE_PRICE_PER_M_INPUT, 7),
  };
}

let originals;
let synthetic;
if (process.argv.includes("--reuse")) {
  console.log("Reusing the saved Every corpus and controlled counterparts…");
  originals = JSON.parse(await readFile(path.join(ROOT, "fixtures", "every-posts.json"), "utf8")).posts;
  synthetic = JSON.parse(await readFile(path.join(ROOT, "fixtures", "every-posts-synthetic.json"), "utf8")).posts;
} else {
  console.log("Pulling Michael Taylor's public Every archive…");
  originals = await scrapeEveryPosts();
  console.log(`Pulled ${originals.length} unique posts. Creating ${SYNTHETIC_COUNT} controlled counterparts…`);
  synthetic = await mapLimit(originals.slice(0, SYNTHETIC_COUNT), 5, createSyntheticCounterpart);
  await mkdir(path.join(ROOT, "fixtures"), { recursive: true });
  await writeFile(path.join(ROOT, "fixtures", "every-posts.json"), `${JSON.stringify({ source: AUTHOR_URL, pulled_at: new Date().toISOString(), posts: originals }, null, 2)}\n`);
  await writeFile(path.join(ROOT, "fixtures", "every-posts-synthetic.json"), `${JSON.stringify({ note: "Controlled AI-style counterparts for paired evaluator testing; not published articles.", posts: synthetic }, null, 2)}\n`);
}

const documents = [
  ...originals.map((post) => ({ ...post, cohort: "published" })),
  ...synthetic.map((post) => ({ ...post, cohort: "controlled_ai" })),
];
console.log(`Running ${documents.length} parallel TypeSafe calls × ${Object.keys(QUESTIONS).length} checks…`);
const started = performance.now();
const liveRows = await Promise.all(documents.map(async (document) => ({ document, ...(await callTypeSafe(`TITLE: ${document.title}\n\n${document.excerpt}`)) })));
const wallMs = round(performance.now() - started, 1);

const rows = liveRows.map(({ document, answers, usage, latency_ms: revealMs }) => {
  const signals = Object.fromEntries(Object.entries(answers).map(([key, answer]) => [key, round(answer.noul, 3)]));
  return {
    id: document.id,
    source_id: document.source_id ?? document.id,
    cohort: document.cohort,
    title: document.title,
    url: document.url,
    excerpt: document.excerpt.replace(/\s+/g, " ").slice(0, 220),
    style_index: round(mean(STYLE_KEYS.map((key) => signals[key]))),
    model_ai_probability: signals.is_ai_generated,
    overall_ai_tells: signals.overall_ai_tells,
    reveal_ms: revealMs,
    signals,
    usage,
  };
});

const paired = synthetic.map((item) => {
  const original = rows.find((row) => row.id === item.source_id);
  const counterpart = rows.find((row) => row.id === item.id);
  return {
    source_id: item.source_id,
    title: original.title,
    published_ai_probability: original.model_ai_probability,
    controlled_ai_probability: counterpart.model_ai_probability,
    probability_delta: round(counterpart.model_ai_probability - original.model_ai_probability),
    published_style_index: original.style_index,
    controlled_ai_style_index: counterpart.style_index,
    style_delta: round(counterpart.style_index - original.style_index),
    separated: counterpart.model_ai_probability > original.model_ai_probability,
  };
});

const publishedRows = rows.filter((row) => row.cohort === "published");
const syntheticRows = rows.filter((row) => row.cohort === "controlled_ai");
const experiment = {
  id: "ai-checker",
  title: "AI writing-pattern checker",
  kind: "ai-checker",
  description: `${originals.length} public Every posts × ${Object.keys(QUESTIONS).length} atomic style checks, plus ${synthetic.length} controlled AI-style counterparts.`,
  source: { author: "Mike Taylor", url: AUTHOR_URL, public_posts: originals.length, scope: "Public article text available without a subscription" },
  questions: AI_CHECKS,
  measured: {
    wall_ms: wallMs,
    calls: rows.length,
    judgments: rows.length * Object.keys(QUESTIONS).length,
    per_call_ms: rows.map((row) => row.reveal_ms),
    usage: summarizeUsage(rows),
  },
  metrics: {
    published_median_ai_probability: round(median(publishedRows.map((row) => row.model_ai_probability))),
    controlled_ai_median_probability: round(median(syntheticRows.map((row) => row.model_ai_probability))),
    published_median_overall_tells: round(median(publishedRows.map((row) => row.overall_ai_tells))),
    controlled_ai_median_overall_tells: round(median(syntheticRows.map((row) => row.overall_ai_tells))),
    published_median_style_index: round(median(publishedRows.map((row) => row.style_index))),
    controlled_ai_median_style_index: round(median(syntheticRows.map((row) => row.style_index))),
    pairwise_separation_rate: round(mean(paired.map((pair) => Number(pair.separated)))),
    mean_probability_delta: round(mean(paired.map((pair) => pair.probability_delta))),
    mean_style_delta: round(mean(paired.map((pair) => pair.style_delta))),
    pairs: paired,
  },
  methodology: {
    caveat: "This measures AI-associated writing patterns, not authorship or provenance. A high score is a review signal, never proof that AI wrote a post.",
    aggregate: `style_index is the unweighted mean of ${STYLE_KEYS.length} atomic pattern probabilities; is_ai_generated and overall_ai_tells are displayed separately and excluded from the index.`,
    validation: "Controlled AI-style counterparts test directional separation. The published cohort is a voice baseline, not a verified no-AI ground-truth set.",
  },
  rows: rows.map(({ usage, ...row }) => row),
};

const dataPath = path.join(ROOT, "public", "experiments.json");
const payload = JSON.parse(await readFile(dataPath, "utf8"));
payload.generated_at = new Date().toISOString();
payload.experiments = [...payload.experiments.filter((item) => item.id !== experiment.id), experiment];
await writeFile(dataPath, `${JSON.stringify(payload, null, 2)}\n`);

const reportPath = path.join(ROOT, "experiments", "REPORT.md");
const report = await readFile(reportPath, "utf8");
const section = `\n## AI writing-pattern checker\n\n- Public Every posts pulled: ${originals.length}\n- Controlled AI-style pairs: ${synthetic.length}\n- Parallel calls / typed judgments: ${rows.length} / ${experiment.measured.judgments}\n- Live wall time: ${wallMs} ms\n- Published median AI probability: ${experiment.metrics.published_median_ai_probability}\n- Controlled AI-style median probability: ${experiment.metrics.controlled_ai_median_probability}\n- Pairwise directional separation: ${Math.round(experiment.metrics.pairwise_separation_rate * 100)}%\n- Mean paired probability delta: ${experiment.metrics.mean_probability_delta}\n\n${experiment.methodology.caveat}\n`;
const totals = payload.experiments.reduce((acc, item) => {
  if (item.id === "judge-grid") {
    acc.calls += item.typesafe.measured.calls;
    acc.judgments += item.typesafe.measured.judgments;
    acc.cost += item.typesafe.measured.usage.estimated_cost_usd;
  } else {
    acc.calls += item.measured.calls;
    acc.judgments += item.measured.judgments;
    acc.cost += item.measured.usage.estimated_cost_usd;
  }
  return acc;
}, { calls: 0, judgments: 0, cost: 0 });
const reportWithTotals = report
  .replace(/Generated: [^\n]+/, `Generated: ${payload.generated_at}`)
  .replace(/- Live TypeSafe API calls: \d+/, `- Live TypeSafe API calls: ${totals.calls}`)
  .replace(/- Typed judgments: \d+/, `- Typed judgments: ${totals.judgments}`)
  .replace(/- Estimated TypeSafe cost: \$[0-9.]+/, `- Estimated TypeSafe cost: $${totals.cost.toFixed(7)}`);
await writeFile(reportPath, `${reportWithTotals.replace(/\n## AI writing-pattern checker[\s\S]*$/m, "").trimEnd()}\n${section}`);

console.log(JSON.stringify({ posts: originals.length, synthetic: synthetic.length, wall_ms: wallMs, judgments: experiment.measured.judgments, cost_usd: experiment.measured.usage.estimated_cost_usd, metrics: experiment.metrics }, null, 2));
