#!/usr/bin/env node
import { readFile, readdir } from "node:fs/promises";
import path from "node:path";
import { performance } from "node:perf_hooks";

const ENDPOINT = "https://api.typesafe.ai/v1/systemone";
const EXTENSIONS = new Set([".ts", ".tsx", ".js", ".jsx", ".md", ".sql", ".py", ".go", ".rs"]);

function round(value, digits = 3) { return Number(value.toFixed(digits)); }
function publicRow(row) { return { file: row.file, score: row.score, latency_ms: row.latency_ms }; }

async function fetchWithRetry(url, options, attempts = 5) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return response;
      const body = await response.text();
      lastError = new Error(`TypeSafe returned ${response.status}: ${body.slice(0, 300)}`);
      if (response.status < 500 && response.status !== 429) throw lastError;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 250 * 2 ** attempt));
  }
  throw lastError;
}

async function walk(root, dir = root) {
  const files = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if ([".git", "node_modules", "dist", "tools"].includes(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...await walk(root, full));
    else if (EXTENSIONS.has(path.extname(entry.name))) files.push(full);
  }
  return files;
}

export async function searchCodebase({ root, query, limit = 5, apiKey = process.env.TYPESAFE_API_KEY }) {
  if (!apiKey) throw new Error("TYPESAFE_API_KEY is required");
  const files = (await walk(root)).sort();
  const question = `Does this file contain implementation or information that directly answers the question: “${query}”?`;
  const started = performance.now();
  const rows = await Promise.all(files.map(async (file) => {
    const callStarted = performance.now();
    const response = await fetchWithRetry(ENDPOINT, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        document: await readFile(file, "utf8"),
        model: "speed_latest",
        questions: { relevant: { type: "noul", instructions: question } },
      }),
    });
    const payload = await response.json();
    return {
      file: path.relative(root, file),
      score: round(payload.answers.relevant.noul, 5),
      latency_ms: round(performance.now() - callStarted, 1),
      usage: payload.usage,
    };
  }));
  rows.sort((a, b) => b.score - a.score);
  const inputTokens = rows.reduce((sum, row) => sum + (row.usage?.input_tokens ?? 0), 0);
  const outputTokens = rows.reduce((sum, row) => sum + (row.usage?.output_tokens ?? 0), 0);
  return {
    query,
    question,
    model: "speed_latest",
    files_scored: rows.length,
    wall_ms: round(performance.now() - started, 1),
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    estimated_cost_usd: round((inputTokens / 1_000_000) * 0.042, 7),
    results: rows.slice(0, limit).map(publicRow),
    all_results: rows.map(publicRow),
  };
}

async function main() {
  const args = process.argv.slice(2);
  const rootIndex = args.indexOf("--root");
  const limitIndex = args.indexOf("--limit");
  const root = path.resolve(rootIndex >= 0 ? args[rootIndex + 1] : ".");
  const limit = limitIndex >= 0 ? Number(args[limitIndex + 1]) : 5;
  const skipped = new Set([rootIndex, rootIndex + 1, limitIndex, limitIndex + 1].filter((index) => index >= 0));
  const query = args.filter((_value, index) => !skipped.has(index)).join(" ").trim();
  if (!query) throw new Error("Usage: typesafe-search.mjs [--root DIR] [--limit N] <question>");
  console.log(JSON.stringify(await searchCodebase({ root, query, limit }), null, 2));
}

if (import.meta.url === `file://${process.argv[1]}`) main().catch((error) => { console.error(error.message); process.exit(1); });
