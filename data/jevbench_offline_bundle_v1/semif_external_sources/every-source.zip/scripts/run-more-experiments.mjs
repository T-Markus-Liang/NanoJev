import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { performance } from "node:perf_hooks";

const ROOT = process.cwd();
const TYPESAFE_URL = "https://api.typesafe.ai/v1/systemone";
const TYPESAFE_PRICE_PER_M_INPUT = 0.042;

async function loadLocalEnv() {
  try {
    const raw = await readFile(path.join(ROOT, ".env.local"), "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2];
    }
  } catch {}
}

await loadLocalEnv();
if (!process.env.TYPESAFE_API_KEY) throw new Error("TYPESAFE_API_KEY is required");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const round = (value, digits = 3) => Number(value.toFixed(digits));
const mean = (values) => values.reduce((sum, value) => sum + value, 0) / Math.max(values.length, 1);

async function fetchWithRetry(url, options, attempts = 6) {
  let lastError;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    try {
      const response = await fetch(url, options);
      if (response.ok) return response;
      const body = await response.text();
      lastError = new Error(`${response.status} ${body.slice(0, 400)}`);
      if (response.status < 500 && response.status !== 429) throw lastError;
    } catch (error) {
      lastError = error;
    }
    await sleep(300 * 2 ** attempt);
  }
  throw lastError;
}

function normalizeQuestions(questionSpecs) {
  return Object.fromEntries(Object.entries(questionSpecs).map(([key, spec]) => [
    key,
    typeof spec === "string" ? { type: "noul", instructions: spec } : spec,
  ]));
}

function compactAnswer(answer) {
  if (answer.type === "noul") return { type: "noul", noul: round(answer.noul, 3) };
  if (answer.type === "choice") return {
    type: "choice",
    choice: answer.choice,
    probabilities: Object.fromEntries(Object.entries(answer.probabilities).map(([key, value]) => [key, round(value, 3)])),
    confidence: round(answer.confidence, 3),
  };
  if (answer.type === "score") return {
    type: "score",
    score: round(answer.score, 3),
    legend: answer.legend,
    probabilities: Object.fromEntries(Object.entries(answer.probabilities).map(([key, value]) => [key, round(value, 3)])),
    confidence: round(answer.confidence, 3),
  };
  throw new Error(`Unsupported TypeSafe answer type: ${answer.type}`);
}

async function callTypeSafe(document, questionSpecs) {
  const questions = normalizeQuestions(questionSpecs);
  const started = performance.now();
  const response = await fetchWithRetry(TYPESAFE_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.TYPESAFE_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ document, model: "speed_latest", questions }),
  });
  const payload = await response.json();
  return { answers: payload.answers, usage: payload.usage, latency_ms: round(performance.now() - started, 1) };
}

function usageSummary(rows) {
  const inputTokens = rows.reduce((sum, row) => sum + (row.usage?.input_tokens ?? 0), 0);
  const outputTokens = rows.reduce((sum, row) => sum + (row.usage?.output_tokens ?? 0), 0);
  return { input_tokens: inputTokens, output_tokens: outputTokens, estimated_cost_usd: round((inputTokens / 1_000_000) * TYPESAFE_PRICE_PER_M_INPUT, 7) };
}

async function runMatrix({ id, title, description, inputs, questions, setup, transform, metrics }) {
  const started = performance.now();
  const live = await Promise.all(inputs.map(async (input) => ({ input, ...(await callTypeSafe(input.document, questions)) })));
  const wallMs = round(performance.now() - started, 1);
  const rows = live.map(({ input, answers, latency_ms }) => {
    const typed_answers = Object.fromEntries(Object.entries(answers).map(([key, answer]) => [key, compactAnswer(answer)]));
    const signals = Object.fromEntries(Object.entries(typed_answers)
      .filter(([, answer]) => answer.type !== "choice")
      .map(([key, answer]) => [key, answer.type === "noul" ? answer.noul : answer.score]));
    return transform({ ...input, typed_answers, signals, reveal_ms: latency_ms });
  });
  return {
    id,
    title,
    kind: "decision-matrix",
    description,
    questions,
    setup,
    measured: { wall_ms: wallMs, calls: rows.length, judgments: rows.length * Object.keys(questions).length, per_call_ms: live.map((row) => row.latency_ms), usage: usageSummary(live) },
    metrics: metrics(rows),
    rows,
  };
}

const SUPPORT_QUESTIONS = {
  angry: "Does this customer sound angry or seriously frustrated?",
  happy: "Does this customer sound pleased, grateful, or delighted?",
  urgent: "Does this issue require a response today?",
  churn_risk: "Does the customer appear likely to cancel or stop using the product?",
  billing_issue: "Is the core issue about billing, payment, or a refund?",
  needs_human: "Should a human support specialist personally handle this conversation?",
};

const SUPPORT_TICKETS = [
  ["Maple Labs", "I was charged three times after the checkout page froze. This is the second billing problem this month. Fix it today or we are cancelling."],
  ["Harbor Studio", "Your support team solved our migration problem in twenty minutes. Please pass along our thanks—everything is working perfectly now."],
  ["Northstar Legal", "We cannot log in and have a client filing due in two hours. Password reset emails never arrive. We need a person immediately."],
  ["Cedar School", "Could you point me to instructions for exporting student reports? No rush; we are planning next semester."],
  ["Orbit Health", "I have explained this four times and keep receiving the same canned response. Our entire team is locked out. I want this escalated."],
  ["Juniper Books", "The new search is fantastic. It found a title our staff had been hunting for all morning."],
  ["Beacon Finance", "The invoice lists the wrong legal entity and procurement will reject it tomorrow morning. Can someone reissue it today?"],
  ["Pinecone AI", "Is dark mode on the roadmap? It would be nice, but it is not blocking us."],
  ["Copper Works", "We upgraded yesterday and none of the promised seats appeared. Sales said it would be instant. This is unacceptable."],
  ["Lumen Travel", "Thank you for adding multi-currency receipts. Our finance team is thrilled."],
  ["Atlas Foods", "A customer can see another customer's order address in the portal. We disabled the integration. Please treat this as a security incident."],
  ["Moss Analytics", "The dashboard takes about ten seconds to load. It is annoying but still usable."],
  ["Birch Media", "Cancel our account and refund the annual renewal. We emailed before renewal and nobody replied."],
  ["Cobalt Design", "Can I change the color of the weekly digest? I may have missed the setting."],
  ["Fable Games", "The launch went smoothly and your onboarding checklist saved us hours. Great work."],
  ["Kite Logistics", "Tracking updates have been delayed since yesterday and our dispatch team is calling drivers manually. We need an ETA."],
  ["Willow Research", "Your API docs show two different parameter names. Which one is current?"],
  ["Summit Retail", "We have asked for a tax receipt for six weeks. Accounting closes today. I am beyond frustrated."],
  ["River Robotics", "The webhook retry feature worked exactly as advertised during our outage. Very impressed."],
  ["Elm Ventures", "Please add my colleague to the workspace when convenient."],
  ["Quartz Energy", "Production exports are returning empty files. Our regulatory report is due tomorrow and this blocks submission."],
  ["Acorn Market", "Why did the price increase without notice? If this is the new rate, we will move to a competitor."],
  ["Nova Museum", "The accessibility improvements are wonderful. Our visitors noticed immediately."],
  ["Tide Security", "A former employee still has administrator access despite being removed yesterday. Revoke it now and confirm the audit trail."],
].map(([account, text], index) => ({ id: `ticket-${String(index + 1).padStart(2, "0")}`, label: account, text, document: `CUSTOMER: ${account}\nMESSAGE: ${text}` }));

const CEO_QUESTIONS = {
  decision_owner: {
    type: "choice",
    instructions: "Who should own the next decision in this Slack thread?",
    criteria: {
      ceo: "The decision requires the CEO's distinctive judgment, authority, or company-level tradeoff.",
      leadership_team: "The decision spans functions but can be resolved by the relevant leadership team without CEO intervention.",
      functional_owner: "A single team or functional owner can decide using existing strategy, policy, or normal execution judgment.",
    },
  },
  needs_ceo_judgment: "Would the CEO's distinctive judgment materially improve this decision right now?",
  strategic_direction: "Does this decision set company or product direction rather than merely execute an existing plan?",
  cross_functional: "Does this decision affect several teams or company-wide priorities?",
  high_cost_of_wrong: "Would a wrong choice be expensive, public, or difficult to unwind?",
  reversible_by_team: "Can the responsible team safely make and reverse this decision without CEO input?",
  enough_context_to_delegate: "Is there enough established policy or context for the team to decide without the CEO?",
};

const CEO_THREADS = [
  { channel: "education", title: "Who is the default learner for Codex?", messages: [["Education lead", "The first course can teach knowledge workers, programmers, or a common foundation. Trying to serve all three makes the examples feel generic."], ["Product lead", "This choice will shape the curriculum, launch promise, and what we build next."], ["Growth lead", "We can test copy later, but we need one audience to design for now."]], decision: "Choose the default learner and accept the segments we will not optimize for in the first release." },
  { channel: "growth", title: "Should the publication keep a hard paywall?", messages: [["Growth lead", "The new product experience gets more people to a paywall, but trial conversion is down."], ["Editorial lead", "Opening more stories may grow reach, but it changes the product readers believe they are buying."], ["Finance lead", "Either path affects the annual plan and pricing narrative. A reversible A/B test will not settle the strategic question."]], decision: "Set the publication's paywall strategy for the next two quarters." },
  { channel: "community", title: "Name the new member community", messages: [["Community lead", "The finalists are Frontier, Next Chapter, and Living in the Future."], ["Brand lead", "Each name signals a different promise and could become a long-lived part of the company identity."], ["Product lead", "We need the name before onboarding and event materials can ship."]], decision: "Choose the enduring name and identity for the member community." },
  { channel: "growth", title: "Can the experimental logo ship next week?", messages: [["Designer", "The launch page uses the experimental agent logo. It has passed brand review."], ["Growth lead", "The image can be swapped after launch without changing the campaign."], ["Brand lead", "I recommend approving it for the two-week test."]], decision: "Approve or replace the already-reviewed launch logo." },
  { channel: "strategy", title: "Which viral growth bets should we fund?", messages: [["Growth lead", "We have five launch ideas: referral credits, shared agent pages, team invites, a public gallery, and creator templates."], ["Product lead", "We can support two without delaying the core roadmap."], ["Finance lead", "The choice determines next quarter's growth budget and product staffing."]], decision: "Pick the two company-level growth loops to fund this quarter." },
  { channel: "editorial", title: "What should count as authorship with AI?", messages: [["Editor", "A contributor supplied the reporting and argument, but an AI drafted nearly every sentence."], ["Legal lead", "Disclosure language can be written once we decide the editorial principle."], ["Audience lead", "Whatever we choose becomes precedent for contributors and staff writers."]], decision: "Set the publication-wide authorship and disclosure policy for AI-drafted articles." },
  { channel: "product", title: "Should customization be called skills, packs, or plugins?", messages: [["Product manager", "User interviews split between skills, packs, and plugins."], ["Design lead", "The object behaves like a skill, and changing the label later is possible."], ["Marketing lead", "We can run a comprehension test this week and choose from the evidence."]], decision: "Choose the product label for the upcoming beta." },
  { channel: "conference", title: "What should anchor the 2027 conference?", messages: [["Events lead", "Sponsors want practical AI implementation; members are asking for frontier research and career transformation."], ["Editorial lead", "The main-stage theme will drive speakers, programming, sponsorship, and the public story for six months."], ["Sales lead", "We need direction before outreach begins on Monday."]], decision: "Choose the main-stage thesis and speaker categories for the 2027 conference." },
  { channel: "audience", title: "How should we answer one reader on social?", messages: [["Community manager", "A reader asked where to learn more about the workflow in today's post."], ["Editor", "The article already links to the guide and the course."], ["Community manager", "I drafted a friendly reply that points to both."]], decision: "Approve or edit a routine social reply to one reader." },
  { channel: "people", title: "Fix the broken new-hire instruction", messages: [["People ops", "The onboarding checklist tells new hires to message an agent before permissions are granted."], ["IT lead", "We can change the step to open a help ticket; that works for every new hire."], ["People ops", "I can update the page today."]], decision: "Replace the inaccessible onboarding step with the standard help-ticket route." },
  { channel: "editorial", title: "What tone should the first help articles use?", messages: [["Support lead", "The first two help articles are accurate but one is playful and one is direct."], ["Editor", "Our style guide already says task instructions should be direct, with personality in examples."], ["Support lead", "I can align both before publishing."]], decision: "Apply the existing style guide to two knowledge-base articles." },
  { channel: "internal-tools", title: "Where should the wiki button link?", messages: [["Operations", "The wiki needs a New request button."], ["IT lead", "The service desk form is the standard destination and already has permissions."], ["Designer", "I can add it beside Search."]], decision: "Add a wiki button using the existing service-desk link." },
  { channel: "developer-experience", title: "Which API parameter name is correct?", messages: [["Engineer", "The quickstart says callback_url, but the reference says redirect_url."], ["API owner", "The shipped endpoint accepts redirect_url; callback_url is stale documentation."], ["Docs lead", "I have a correction ready."]], decision: "Correct the stale documentation to match the shipped API." },
  { channel: "conference", title: "Choose the sponsor photo-booth filter", messages: [["Events lead", "The sponsor approved the activation and wants one of three filters."], ["Designer", "All three meet the brand rules; option B tested best with staff."], ["Events lead", "I can send B today unless there is an objection."]], decision: "Select one execution detail inside an already-approved activation." },
  { channel: "engineering", title: "Reuse the internal tool or build a replacement?", messages: [["Engineering lead", "The existing tool handles 80% of the workflow but has a brittle deployment."], ["Operations", "A replacement takes two engineer-weeks and removes three manual steps."], ["Product lead", "This only affects one internal team and fits within the approved automation budget."]], decision: "Choose the implementation approach for one team's internal workflow." },
  { channel: "strategy", title: "How should the company segment customers?", messages: [["Sales lead", "Sales groups customers by company size; product groups them by job-to-be-done; editorial uses role."], ["Product lead", "The mismatch is now breaking reporting, roadmap debates, and launch planning."], ["Finance lead", "A shared model changes targets and resource allocation across the company."]], decision: "Choose the company-wide customer segmentation model." },
  { channel: "facilities", title: "Schedule the office furniture delivery", messages: [["Office manager", "The vendor can arrive Tuesday from 10–12 or Thursday from 2–4."], ["Facilities", "Both windows work; Thursday avoids the all-hands."], ["Office manager", "I'll book Thursday unless anyone sees a conflict."]], decision: "Select a delivery window for approved office furniture." },
  { channel: "editorial", title: "Republish the hit or relaunch the weak story?", messages: [["Audience lead", "We have one distribution slot. Republishing the hit is likely to bring reliable traffic; relaunching the weaker story may teach us whether the original packaging failed."], ["Editor", "Both fit the editorial calendar and neither changes our broader strategy."], ["Audience lead", "I can choose using our normal reach-versus-learning rubric."]], decision: "Choose which existing article gets this week's distribution slot." },
].map((thread, index) => ({
  id: `thread-${String(index + 1).padStart(2, "0")}`,
  label: thread.title,
  text: thread.decision,
  channel: thread.channel,
  messages: thread.messages,
  decision: thread.decision,
  document: `SYNTHETIC SLACK THREAD · #${thread.channel}\n\n${thread.messages.map(([speaker, message]) => `${speaker}: ${message}`).join("\n\n")}\n\nOPEN DECISION: ${thread.decision}`,
}));

const EMAIL_QUESTIONS = {
  reply_action: {
    type: "choice",
    instructions: "What should the recipient do with this email?",
    criteria: {
      reply_now: "Respond or act immediately because delay of even a few hours creates material risk or blocks urgent work.",
      reply_today: "Respond before the end of today, but it does not require immediate interruption.",
      read_later: "Read when convenient; it may be useful but does not need a response today.",
      no_reply: "No response is needed, such as a receipt, confirmation, announcement, or explicitly informational message.",
    },
  },
  urgency: {
    type: "score",
    instructions: "How urgent is a response or action on this email?",
    criteria: [
      "No response or action is needed.",
      "Action can safely wait beyond today.",
      "Action should happen before the end of today.",
      "Immediate or blocking: delay of a few hours creates material harm or misses a near-term cutoff.",
    ],
  },
  explicit_deadline: "Does the email contain a near-term explicit deadline?",
  blocks_others: "Is someone else blocked until the recipient responds?",
  financial_or_legal: "Could delay create meaningful financial, contractual, legal, or security risk?",
};

const EMAILS = [
  ["Contract signature needed by 3 PM", "Legal approved the final language. The counterparty's offer expires at 3 PM today; please sign or tell us to walk away.", true],
  ["Weekly product digest", "Here are this week's shipped features and usage charts. No action required.", false],
  ["Production access still active", "A contractor whose engagement ended yesterday still appears to have production access. Please confirm revocation immediately.", true],
  ["Coffee next month?", "I will be in New York sometime next month and would enjoy catching up if schedules align.", false],
  ["Customer renewal blocked", "The customer will not renew until you approve the revised pricing. Their procurement call is tomorrow morning.", true],
  ["Receipt for your records", "Your payment was processed successfully. This receipt is for your records.", false],
  ["Speaker bio due today", "The conference program goes to print tonight. Please send the approved 80-word bio by 5 PM.", true],
  ["Interesting AI paper", "Thought you might enjoy this research paper. No need to respond.", false],
  ["Payroll account mismatch", "Payroll closes in four hours and the bank account on file failed verification. Please update it before the cutoff.", true],
  ["Office plants", "Should we order two more plants for the meeting room? We can decide whenever.", false],
  ["Refund escalation", "A customer says they will dispute the charge today unless a manager confirms the refund.", true],
  ["Newsletter confirmation", "Please confirm your subscription by clicking the link within seven days.", false],
  ["Board deck numbers", "Finance is waiting on your forecast before finalizing tomorrow's board deck.", true],
  ["Calendar accepted", "Your invitation was accepted. No response is necessary.", false],
  ["Trademark objection deadline", "Outside counsel needs your decision by noon tomorrow to file the response on time.", true],
  ["Travel itinerary", "Your flights and hotel are confirmed for next month. Review when convenient.", false],
  ["Site outage update", "The site is down for all users. Engineering has a mitigation ready but needs your approval to enable maintenance mode.", true],
  ["Podcast recommendation", "This episode reminded me of our conversation. Listen whenever you have time.", false],
  ["Candidate offer approval", "The candidate has another offer and needs our final compensation package by end of day.", true],
  ["Monthly invoice available", "Your monthly invoice is ready in the billing portal.", false],
  ["Press quote approval", "The reporter files in 90 minutes and needs confirmation that the quote is accurate.", true],
  ["Team offsite survey", "Please share dietary preferences by next Friday.", false],
  ["Data deletion request", "A verified customer deletion request reaches its statutory deadline tomorrow. Approval is required to complete it.", true],
  ["Feature announcement", "We launched the requested feature this morning. Sharing for awareness; no response needed.", false],
].map(([subject, body, expected], index) => ({ id: `email-${String(index + 1).padStart(2, "0")}`, label: subject, subject, body, expected, document: `SUBJECT: ${subject}\nBODY: ${body}` }));

const ADS = {
  A: "Your company already knows the answer. Every Agent finds it across your tools and turns it into finished work.",
  B: "Stop losing Fridays to busywork. Give repetitive research, writing, and coordination to an AI teammate.",
  C: "The best people at your company make hundreds of judgment calls. Capture how they think and let everyone use it.",
};
const PERSONA_QUESTIONS = {
  ad_choice: {
    type: "choice",
    instructions: "Which advertisement would this person be most likely to click?",
    criteria: {
      A: `Company knowledge angle: “${ADS.A}”`,
      B: `Time-saving angle: “${ADS.B}”`,
      C: `Captured judgment angle: “${ADS.C}”`,
    },
  },
};
const ROLES = ["founder", "operations leader", "marketing lead", "consultant", "product manager"];
const MATURITY = ["AI skeptic", "AI curious", "weekly AI user", "daily AI user", "AI automation expert"];
const NEEDS = ["find internal knowledge", "save time on repetitive work", "make better decisions", "coordinate cross-functional projects"];
const PERSONAS = ROLES.flatMap((role) => MATURITY.flatMap((maturity) => NEEDS.map((need) => ({ role, maturity, need }))))
  .map((persona, index) => ({
    id: `persona-${String(index + 1).padStart(3, "0")}`,
    label: `${persona.role} · ${persona.maturity} · ${persona.need}`,
    ...persona,
    document: `PERSONA\nRole: ${persona.role}\nAI relationship: ${persona.maturity}\nPrimary need: ${persona.need}\n\nADVERTISEMENT A\n${ADS.A}\n\nADVERTISEMENT B\n${ADS.B}\n\nADVERTISEMENT C\n${ADS.C}`,
  }));

console.log("Running customer-service sentiment triage…");
const support = await runMatrix({
  id: "customer-voice",
  title: "Which customers need help first?",
  description: `${SUPPORT_TICKETS.length} synthetic support conversations scored for emotion, urgency, churn risk, and escalation need.`,
  inputs: SUPPORT_TICKETS,
  questions: SUPPORT_QUESTIONS,
  setup: { provenance: "Synthetic support inbox; no real customer data", input_count: SUPPORT_TICKETS.length, unit: "one support message", decision: "Rank the angriest, happiest, and most urgent customers for a support lead." },
  transform: (row) => ({ ...row, anger_score: row.signals.angry, happiness_score: row.signals.happy, priority: round(.28 * row.signals.angry + .25 * row.signals.urgent + .22 * row.signals.churn_risk + .25 * row.signals.needs_human) }),
  metrics: (rows) => ({ most_angry: [...rows].sort((a, b) => b.anger_score - a.anger_score).slice(0, 5).map(({ id, label, anger_score }) => ({ id, label, value: anger_score })), happiest: [...rows].sort((a, b) => b.happiness_score - a.happiness_score).slice(0, 5).map(({ id, label, happiness_score }) => ({ id, label, value: happiness_score })), highest_priority: [...rows].sort((a, b) => b.priority - a.priority).slice(0, 5).map(({ id, label, priority }) => ({ id, label, value: priority })) }),
});

console.log("Running CEO-judgment radar…");
const ceo = await runMatrix({
  id: "ceo-radar",
  title: "Which decisions need the CEO?",
  description: `${CEO_THREADS.length} synthetic Slack threads routed to the CEO, leadership team, or functional owner.`,
  inputs: CEO_THREADS,
  questions: CEO_QUESTIONS,
  setup: { provenance: "Synthetic, de-identified Slack-style threads inspired by recent company decision themes; no raw Slack messages published", input_count: CEO_THREADS.length, unit: "one complete Slack thread plus its open decision", decision: "Route each thread to the CEO, leadership team, or functional owner, then rank the CEO queue." },
  transform: (row) => {
    const ownerAnswer = row.typed_answers.decision_owner;
    const ceoProbability = ownerAnswer.probabilities.ceo;
    const priority = round(.42 * ceoProbability + .18 * row.signals.needs_ceo_judgment + .12 * row.signals.strategic_direction + .1 * row.signals.cross_functional + .08 * row.signals.high_cost_of_wrong + .05 * (1 - row.signals.reversible_by_team) + .05 * (1 - row.signals.enough_context_to_delegate));
    return { ...row, owner: ownerAnswer.choice, owner_confidence: ownerAnswer.confidence, ceo_probability: ceoProbability, priority };
  },
  metrics: (rows) => ({
    top: [...rows].sort((a, b) => b.priority - a.priority).slice(0, 7).map(({ id, label, priority, owner, ceo_probability }) => ({ id, label, value: priority, owner, ceo_probability })),
    routing_counts: Object.fromEntries(["ceo", "leadership_team", "functional_owner"].map((owner) => [owner, rows.filter((row) => row.owner === owner).length])),
    reviewed_slack_window: "2026-08-19 through 2026-08-28",
    reviewed_channels: [...new Set(CEO_THREADS.map((thread) => thread.channel))],
  }),
});

console.log("Running inbox urgency triage…");
const inbox = await runMatrix({
  id: "inbox-urgency",
  title: "Which emails need a reply today?",
  description: `${EMAILS.length} synthetic emails scored for reply urgency, deadlines, blockers, and downside risk.`,
  inputs: EMAILS,
  questions: EMAIL_QUESTIONS,
  setup: { provenance: "Synthetic inbox; no private email connection or real email content", input_count: EMAILS.length, unit: "one email subject and body", decision: "Make a short reply-today queue while leaving newsletters and receipts for later." },
  transform: (row) => {
    const actionAnswer = row.typed_answers.reply_action;
    const urgencyScore = row.typed_answers.urgency.score;
    const priority = round(.42 * (urgencyScore / 3) + .2 * (actionAnswer.probabilities.reply_now + actionAnswer.probabilities.reply_today) + .13 * row.signals.explicit_deadline + .13 * row.signals.blocks_others + .12 * row.signals.financial_or_legal);
    const predicted = actionAnswer.choice === "reply_now" || actionAnswer.choice === "reply_today";
    return { ...row, action: actionAnswer.choice, action_confidence: actionAnswer.confidence, urgency_score: urgencyScore, priority, predicted, correct: predicted === row.expected };
  },
  metrics: (rows) => ({
    accuracy: round(mean(rows.map((row) => Number(row.correct)))),
    reply_today_count: rows.filter((row) => row.predicted).length,
    action_counts: Object.fromEntries(["reply_now", "reply_today", "read_later", "no_reply"].map((action) => [action, rows.filter((row) => row.action === action).length])),
    top: [...rows].sort((a, b) => b.priority - a.priority).slice(0, 7).map(({ id, subject, priority, action, urgency_score }) => ({ id, label: subject, value: priority, action, urgency_score })),
  }),
});

console.log("Running 100-persona ad panel…");
const personas = await runMatrix({
  id: "persona-panel",
  title: "Which ad would 100 AI personas click?",
  description: `${PERSONAS.length} synthetic personas each classified into the ad they would be most likely to click.`,
  inputs: PERSONAS,
  questions: PERSONA_QUESTIONS,
  setup: { provenance: "100 synthetic personas generated from a 5 role × 5 AI-maturity × 4 need matrix", input_count: PERSONAS.length, unit: "one persona shown three ads", decision: "Estimate which message wins overall and which segments respond to each angle.", ads: ADS },
  transform: (row) => {
    const answer = row.typed_answers.ad_choice;
    return { ...row, winner: answer.choice, winner_score: answer.probabilities[answer.choice], choice_probabilities: answer.probabilities, choice_confidence: answer.confidence };
  },
  metrics: (rows) => {
    const averages = Object.fromEntries(["A", "B", "C"].map((ad) => [ad, round(mean(rows.map((row) => row.choice_probabilities[ad])))]));
    const winner = Object.entries(averages).sort((a, b) => b[1] - a[1])[0][0];
    const wins = Object.fromEntries(["A", "B", "C"].map((ad) => [ad, rows.filter((row) => row.winner === ad).length]));
    return { averages, winner, wins, ads: ADS };
  },
});

const dataPath = path.join(ROOT, "public", "experiments.json");
const payload = JSON.parse(await readFile(dataPath, "utf8"));
payload.generated_at = new Date().toISOString();
const newIds = new Set([support.id, ceo.id, inbox.id, personas.id]);
payload.experiments = [...payload.experiments.filter((item) => !newIds.has(item.id)), support, ceo, inbox, personas];
payload.methodology.slack_research = { window: ceo.metrics.reviewed_slack_window, note: ceo.setup.provenance };
await writeFile(dataPath, `${JSON.stringify(payload, null, 2)}\n`);

const fixtures = {
  generated_at: payload.generated_at,
  privacy: "All customer and email inputs are synthetic. CEO-routing inputs are synthetic, de-identified Slack-style threads; no raw private Slack text is included.",
  experiments: {
    customer_voice: { questions: SUPPORT_QUESTIONS, inputs: SUPPORT_TICKETS },
    ceo_radar: { questions: CEO_QUESTIONS, inputs: CEO_THREADS, slack_basis: ceo.metrics },
    inbox_urgency: { questions: EMAIL_QUESTIONS, inputs: EMAILS },
    persona_panel: { questions: PERSONA_QUESTIONS, ads: ADS, inputs: PERSONAS },
  },
};
await writeFile(path.join(ROOT, "fixtures", "application-experiments.json"), `${JSON.stringify(fixtures, null, 2)}\n`);

const totals = payload.experiments.reduce((acc, item) => {
  const measured = item.id === "judge-grid" ? item.typesafe.measured : item.measured;
  acc.calls += measured.calls;
  acc.judgments += measured.judgments;
  acc.cost += measured.usage.estimated_cost_usd;
  return acc;
}, { calls: 0, judgments: 0, cost: 0 });

console.log(JSON.stringify({ generated_at: payload.generated_at, experiments: [support, ceo, inbox, personas].map((item) => ({ id: item.id, wall_ms: item.measured.wall_ms, calls: item.measured.calls, judgments: item.measured.judgments, cost: item.measured.usage.estimated_cost_usd, metrics: item.metrics })), totals }, null, 2));
