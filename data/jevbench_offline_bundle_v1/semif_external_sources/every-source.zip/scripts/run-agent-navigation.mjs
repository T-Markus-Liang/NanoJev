import { mkdtemp, mkdir, readFile, writeFile, copyFile } from "node:fs/promises";
import { spawn } from "node:child_process";
import path from "node:path";
import os from "node:os";
import { performance } from "node:perf_hooks";
import { searchCodebase } from "./typesafe-search.mjs";

const ROOT = process.cwd();
const TASK = {
  id: "refresh-token-replay",
  prompt: "Where is refresh-token rotation and replay protection implemented? Explain how a replay is detected, what is invalidated, and what credential is returned after a successful exchange. Cite the exact file and symbols.",
  target: "src/identity/credential-family.ts",
  expected_symbols: ["exchangeFamilyProof", "consumeCurrent", "revokeFamily", "issueSuccessor"],
};

async function loadLocalEnv() {
  try {
    const raw = await readFile(path.join(ROOT, ".env.local"), "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
      if (match && !process.env[match[1]]) process.env[match[1]] = match[2];
    }
  } catch {}
}

function round(value, digits = 3) { return Number(value.toFixed(digits)); }

async function materialize(fixture, withTool) {
  const dir = await mkdtemp(path.join(os.tmpdir(), withTool ? "typesafe-agent-" : "manual-agent-"));
  for (const file of fixture.files) {
    const target = path.join(dir, file.path);
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, file.content);
  }
  if (withTool) {
    await mkdir(path.join(dir, "tools"), { recursive: true });
    await copyFile(path.join(ROOT, "scripts", "typesafe-search.mjs"), path.join(dir, "tools", "typesafe-search.mjs"));
  }
  return dir;
}

function classifyCommand(command) {
  if (command.includes("typesafe-search.mjs")) return "typesafe_search";
  if (/\b(rg|grep|find|ls)\b/.test(command)) return "search";
  if (/\b(cat|sed|nl|head|tail)\b/.test(command)) return "read";
  return "shell";
}

function visibleCommand(command) {
  return command.replaceAll(ROOT, ".").replace(/\s+/g, " ").slice(0, 180);
}

function pathsFromRead(command) {
  if (!/\b(cat|sed|nl|head|tail)\b/.test(command)) return [];
  return [...command.matchAll(/[A-Za-z0-9_./-]+\.(?:ts|tsx|js|jsx|md|sql|py|go|rs)/g)].map((match) => match[0].replace(/^\.\//, ""));
}

async function runClaudeTrial({ id, label, cwd, assisted }) {
  const prompt = assisted
    ? `You are measuring codebase navigation in a synthetic repository. Do not modify anything. Begin by running this exact search pattern with the question below:\nnode tools/typesafe-search.mjs --root . --limit 5 \"${TASK.prompt}\"\nThen open only the most useful returned file or files, verify the implementation, and answer the task. Return a concise explanation citing the exact file and symbols.\n\nTASK: ${TASK.prompt}`
    : `You are measuring codebase navigation in a synthetic repository. Do not modify anything. Use ordinary shell file listing, keyword search, and file reading to navigate the repository and answer the task. You do not have a semantic retrieval tool. Return a concise explanation citing the exact file and symbols.\n\nTASK: ${TASK.prompt}`;

  const args = [
    "-p", prompt,
    "--output-format", "stream-json",
    "--verbose",
    "--permission-mode", "dontAsk",
    "--allowedTools", "Bash",
    "--no-session-persistence",
    "--strict-mcp-config",
    "--mcp-config", '{"mcpServers":{}}',
    "--disable-slash-commands",
    "--effort", "low",
    "--max-budget-usd", "1.50",
  ];

  const started = performance.now();
  const events = [];
  const tools = new Map();
  const opened = new Set();
  let model = "Claude Headless";
  let finalAnswer = "";
  let totalCost = 0;
  let durationMs = 0;
  let firstTargetMs = null;
  let buffer = "";

  await new Promise((resolve, reject) => {
    const child = spawn("claude", args, { cwd, env: process.env, stdio: ["ignore", "pipe", "pipe"] });
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr += chunk.toString(); });
    child.stdout.on("data", (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.trim()) continue;
        let event;
        try { event = JSON.parse(line); } catch { continue; }
        const atMs = round(performance.now() - started, 1);
        if (event.type === "system" && event.subtype === "init") model = event.model ?? model;
        if (event.type === "assistant") {
          for (const block of event.message?.content ?? []) {
            if (block.type !== "tool_use") continue;
            const isRead = block.name === "Read";
            const filePath = isRead ? String(block.input?.file_path ?? "").replace(`${cwd}/`, "") : "";
            const command = isRead ? `Read ${filePath}` : block.input?.command ?? "";
            const trajectoryEvent = {
              id: block.id,
              at_ms: atMs,
              kind: isRead ? "read" : classifyCommand(command),
              label: block.input?.description ?? (isRead ? `Open ${filePath}` : visibleCommand(command)),
              command: visibleCommand(command),
              status: "running",
            };
            tools.set(block.id, trajectoryEvent);
            events.push(trajectoryEvent);
            if (isRead && filePath) opened.add(filePath);
            for (const file of pathsFromRead(command)) opened.add(file);
            if ((filePath === TASK.target || command.includes(TASK.target)) && firstTargetMs === null) firstTargetMs = atMs;
          }
        }
        if (event.type === "user") {
          for (const block of event.message?.content ?? []) {
            if (block.type !== "tool_result") continue;
            const prior = tools.get(block.tool_use_id);
            if (!prior) continue;
            const text = typeof block.content === "string" ? block.content : JSON.stringify(block.content);
            prior.completed_ms = atMs;
            prior.duration_ms = round(atMs - prior.at_ms, 1);
            prior.status = block.is_error ? "error" : "complete";
            prior.observation = text.replace(/\s+/g, " ").slice(0, 220);
            if (text.includes(TASK.target) && firstTargetMs === null) firstTargetMs = atMs;
          }
        }
        if (event.type === "result") {
          finalAnswer = event.result ?? finalAnswer;
          totalCost = event.total_cost_usd ?? totalCost;
          durationMs = event.duration_ms ?? atMs;
          if (event.is_error) reject(new Error(`Claude trial failed: ${event.subtype ?? "unknown"} ${event.errors?.join("; ") ?? ""}`));
        }
      }
    });
    child.on("error", reject);
    child.on("close", (code) => code === 0 ? resolve() : reject(new Error(`Claude exited ${code}: ${stderr.slice(-1000)}`)));
  });

  const lower = finalAnswer.toLowerCase();
  const correct = lower.includes(TASK.target.toLowerCase()) && TASK.expected_symbols.filter((symbol) => lower.includes(symbol.toLowerCase())).length >= 3;
  return {
    id,
    label,
    model,
    correct,
    wall_ms: round(durationMs || performance.now() - started, 1),
    time_to_target_ms: firstTargetMs,
    tool_calls: events.length,
    search_rounds: events.filter((event) => ["search", "typesafe_search"].includes(event.kind)).length,
    files_opened: opened.size,
    opened_files: [...opened],
    estimated_claude_cost_usd: round(totalCost, 6),
    events,
    answer: finalAnswer,
  };
}

await loadLocalEnv();
if (!process.env.TYPESAFE_API_KEY) throw new Error("TYPESAFE_API_KEY is required");

const fixture = JSON.parse(await readFile(path.join(ROOT, "fixtures", "agent-codebase.json"), "utf8"));
const baselineDir = await materialize(fixture, false);
const assistedDir = await materialize(fixture, true);
const typesafe = await searchCodebase({ root: assistedDir, query: TASK.prompt, limit: fixture.files.length });
const typesafeSection = {
  question: typesafe.question,
  ranking: typesafe.all_results,
  measured: {
    wall_ms: typesafe.wall_ms,
    calls: typesafe.files_scored,
    judgments: typesafe.files_scored,
    per_call_ms: typesafe.all_results.map((row) => row.latency_ms),
    usage: {
      input_tokens: typesafe.input_tokens,
      output_tokens: typesafe.output_tokens,
      estimated_cost_usd: typesafe.estimated_cost_usd,
    },
  },
};

if (process.argv.includes("--typesafe-only")) {
  const outputPath = path.join(ROOT, "experiments", "agent-navigation.json");
  const existing = JSON.parse(await readFile(outputPath, "utf8"));
  existing.typesafe = typesafeSection;
  await writeFile(outputPath, `${JSON.stringify(existing, null, 2)}\n`);
  console.log(JSON.stringify({ output: "experiments/agent-navigation.json", refreshed: "typesafe", measured: typesafeSection.measured, top: typesafeSection.ranking.slice(0, 3) }, null, 2));
  process.exit(0);
}

console.log("Running Claude Headless with ordinary file search…");
const baseline = await runClaudeTrial({ id: "manual-search", label: "Manual file search", cwd: baselineDir, assisted: false });
console.log("Running Claude Headless with the TypeSafe search CLI…");
const assisted = await runClaudeTrial({ id: "typesafe-rag", label: "TypeSafe-guided search", cwd: assistedDir, assisted: true });

const experiment = {
  id: "agent-navigation",
  title: "Agent navigation race",
  kind: "agent-trajectory",
  description: "The same Claude Headless task and synthetic codebase, once with ordinary shell search and once with a TypeSafe relevance CLI.",
  task: TASK,
  corpus: {
    name: fixture.name,
    description: fixture.description,
    files: fixture.files.length,
    target: fixture.target,
    manifest: fixture.files.map((file) => ({ path: file.path, content: file.content, excerpt: file.content.replace(/\s+/g, " ").slice(0, 170) })),
  },
  typesafe: typesafeSection,
  trials: [baseline, assisted],
  methodology: {
    model_control: "Both trials used the same installed Claude Headless default model and low effort, with Bash as the only allowed tool.",
    baseline: "The baseline could list, keyword-search, and read files.",
    assisted: "The assisted run was required to call the supplied TypeSafe CLI first, then verify the returned file in source.",
    caveat: "One run per condition on a synthetic repository. Claude latency and tool choices vary, so treat this as an inspectable trajectory demonstration, not a statistically powered speed benchmark.",
  },
};

await mkdir(path.join(ROOT, "experiments"), { recursive: true });
await writeFile(path.join(ROOT, "experiments", "agent-navigation.json"), `${JSON.stringify(experiment, null, 2)}\n`);
console.log(JSON.stringify({
  output: "experiments/agent-navigation.json",
  typesafe: { wall_ms: typesafe.wall_ms, top: typesafe.results.slice(0, 3) },
  trials: experiment.trials.map(({ id, model, correct, wall_ms, time_to_target_ms, tool_calls, search_rounds, files_opened, estimated_claude_cost_usd }) => ({ id, model, correct, wall_ms, time_to_target_ms, tool_calls, search_rounds, files_opened, estimated_claude_cost_usd })),
}, null, 2));
