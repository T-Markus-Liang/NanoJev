import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const ROOT = process.cwd();
const dataPath = path.join(ROOT, "public", "experiments.json");
const dataRaw = await readFile(dataPath, "utf8");
const data = JSON.parse(dataRaw);
const sha256 = (value) => createHash("sha256").update(value).digest("hex");

function measured(experiment) {
  return ["judge-grid", "agent-navigation"].includes(experiment.id) ? experiment.typesafe.measured : experiment.measured;
}

function wall(experiment) {
  if (experiment.id === "judge-grid") return experiment.typesafe.mean_wall_ms;
  if (experiment.id === "agent-navigation") return experiment.typesafe.measured.wall_ms;
  return experiment.measured.wall_ms;
}

const receipts = data.experiments.map((experiment) => {
  const stats = measured(experiment);
  return {
    id: experiment.id,
    title: experiment.title,
    model: "speed_latest",
    wall_ms: wall(experiment),
    calls: stats.calls,
    judgments: stats.judgments,
    input_tokens: stats.usage.input_tokens,
    output_tokens: stats.usage.output_tokens,
    estimated_cost_usd: stats.usage.estimated_cost_usd,
  };
});

const totals = receipts.reduce((acc, row) => {
  acc.calls += row.calls;
  acc.judgments += row.judgments;
  acc.cost += row.estimated_cost_usd;
  return acc;
}, { calls: 0, judgments: 0, cost: 0 });

const artifactFiles = [
  "public/experiments.json",
  "fixtures/every-posts.json",
  "fixtures/every-posts-synthetic.json",
  "fixtures/application-experiments.json",
  "fixtures/agent-codebase.json",
  "experiments/agent-navigation.json",
  "experiments/qmd-company-brain.json",
];
const artifactHashes = {};
for (const relative of artifactFiles) artifactHashes[relative] = sha256(await readFile(path.join(ROOT, relative)));

const manifest = {
  purpose: "Run manifest for the TypeSafe Parallel Judgment Lab",
  generated_at: data.generated_at,
  api: { endpoint: data.methodology.endpoint, model: data.methodology.model, pricing: data.methodology.pricing },
  statement: "Every probability and timing displayed on the site is loaded from public/experiments.json, written from successful API responses by the listed runners. Hashes record the exact data version used by this build.",
  runner_commands: [
    "node scripts/run-experiments.mjs",
    "node scripts/run-agent-navigation.mjs",
    "node scripts/merge-agent-navigation.mjs",
    "QMD_BIN=qmd node scripts/run-qmd-comparison.mjs",
    "node scripts/run-ai-checker.mjs --reuse",
    "node scripts/run-more-experiments.mjs",
    "node scripts/build-downloads.mjs",
  ],
  privacy: "Customer and email data are synthetic. CEO-routing inputs are synthetic, de-identified Slack-style threads. No raw private Slack or email content is published.",
  totals: { calls: totals.calls, judgments: totals.judgments, estimated_cost_usd: Number(totals.cost.toFixed(7)) },
  experiments: receipts,
  artifact_sha256: artifactHashes,
};

const primaryResults = {
  "code-rag": (e) => `Recall@1 ${Math.round(e.metrics.recall_at_1 * 100)}%; MRR ${e.metrics.mrr}`,
  "agent-navigation": (e) => `Claude + TypeSafe ${(e.trials[1].wall_ms / 1000).toFixed(1)}s vs manual ${(e.trials[0].wall_ms / 1000).toFixed(1)}s; both correct`,
  "company-brain": (e) => `Recall@3 ${Math.round(e.metrics.recall_at_3 * 100)}%; MRR ${e.metrics.mrr}`,
  "judge-grid": (e) => `${Math.round(e.typesafe.accuracy * 100)}% label agreement; ${e.typesafe.mean_cell_std.toFixed(4)} repeat variation`,
  "action-firewall": (e) => `${Math.round(e.measured.accuracy * 100)}% decision agreement`,
  "vc-diligence": (e) => `${Math.round(e.measured.accuracy * 100)}% tier agreement`,
  "ai-checker": (e) => `${Math.round(e.metrics.pairwise_separation_rate * 100)}% paired directional separation; +${e.metrics.mean_probability_delta} mean P(AI) lift`,
  "customer-voice": (e) => `Highest support priority: ${e.metrics.highest_priority[0].label} (${e.metrics.highest_priority[0].value})`,
  "ceo-radar": (e) => `Highest CEO priority: ${e.metrics.top[0].label} (${e.metrics.top[0].value})`,
  "inbox-urgency": (e) => `${Math.round(e.metrics.accuracy * 100)}% synthetic-label agreement; ${e.metrics.reply_today_count} reply-today emails`,
  "persona-panel": (e) => `Ad ${e.metrics.winner} won; ${Math.round(e.metrics.averages[e.metrics.winner] * 100)}% modeled click share; ${e.metrics.wins[e.metrics.winner]} persona selections`,
};

const reportRows = data.experiments.map((experiment, index) => {
  const receipt = receipts[index];
  return `| ${index + 1} | ${experiment.title} | ${receipt.calls} | ${receipt.judgments} | ${receipt.wall_ms} ms | $${receipt.estimated_cost_usd.toFixed(7)} | ${primaryResults[experiment.id](experiment)} |`;
}).join("\n");

const report = `# TypeSafe Parallel Judgment Lab — experiment report

Generated from saved live responses: ${data.generated_at}

## Bottom line

${data.experiments.length} experiments produced ${totals.judgments.toLocaleString("en-US")} typed judgments across ${totals.calls} TypeSafe API calls for an estimated $${totals.cost.toFixed(7)}. The site replays the recorded probability, retrieval, agent-tool, and timing data from these runs.

| # | Experiment | Calls | Judgments | Measured wall time | TypeSafe cost | Primary result |
| ---: | --- | ---: | ---: | ---: | ---: | --- |
${reportRows}

## Experiment setup

Each runner sends one document or scenario plus a JSON object of typed questions to \`${data.methodology.endpoint}\` with model \`${data.methodology.model}\`. The lab demonstrates Noul yes/no probabilities, Choice classifications with full probability distributions, and Score rubrics with expected values. Retrieval ranks probabilities; routing and triage experiments combine typed answers with visible formulas in code.

The exact inputs are in \`fixtures/\`. The exact question text and saved row-level probabilities are in \`public/experiments.json\`. The complete runnable walkthrough is in \`notebooks/TypeSafe_Parallel_Judgment_Lab.ipynb\`.

## Scope and limitations

- The saved JSON includes every displayed probability, per-call latency, token usage, and estimated cost.
- \`experiments/RUN_MANIFEST.json\` records totals, runner commands, and SHA-256 hashes for the data artifacts.
- Customer-support and email examples are synthetic.
- The CEO radar uses synthetic, de-identified Slack-style threads inspired by recent company themes; raw Slack messages are not published.
- The agent-navigation race is one run per condition on a synthetic repository, not a statistically powered agent benchmark.
- The company-brain comparison uses QMD 2.8.3 keyword and vector search over the same ten markdown documents; QMD index and embedding setup are reported separately from query time.
- The AI-writing checker detects style patterns, not authorship.
- The 100-person persona panel predicts synthetic stated preference, not real ad clicks.
- Artifact hashes make it easy to detect changes to the recorded experiment data.
`;

function markdownCell(source) { return { cell_type: "markdown", metadata: {}, source: source.split("\n").map((line) => `${line}\n`) }; }
function codeCell(source) { return { cell_type: "code", execution_count: null, metadata: {}, outputs: [], source: source.split("\n").map((line) => `${line}\n`) }; }

const notebook = {
  cells: [
    markdownCell(`# TypeSafe Parallel Judgment Lab\n\nThis notebook is the guided walkthrough and rerun companion for all **${data.experiments.length} measured experiments**. It covers the recorded results, exact questions, inputs, formulas, retrieval rankings, agent trajectories, and runner commands.`),
    codeCell(`from pathlib import Path\nimport json, os, subprocess, urllib.request\n\ndef find_root():\n    here = Path.cwd()\n    for candidate in [here, *here.parents]:\n        if (candidate / "public" / "experiments.json").exists():\n            return candidate\n    raise FileNotFoundError("Open this notebook from the downloaded source bundle")\n\nROOT = find_root()\nDATA = json.loads((ROOT / "public" / "experiments.json").read_text())\nMANIFEST = json.loads((ROOT / "experiments" / "RUN_MANIFEST.json").read_text())\nprint("Saved run:", DATA["generated_at"])\nprint("Experiments:", len(DATA["experiments"]))\nprint("Receipts:", MANIFEST["totals"])`),
    markdownCell(`## 1. Review the recorded run\n\nThe table below is computed directly from the results file used by the website.`),
    codeCell(`def receipt(e):\n    uses_nested = e["id"] in {"judge-grid", "agent-navigation"}\n    m = e["typesafe"]["measured"] if uses_nested else e["measured"]\n    wall = e["typesafe"]["mean_wall_ms"] if e["id"] == "judge-grid" else m["wall_ms"]\n    return {"id": e["id"], "calls": m["calls"], "judgments": m["judgments"], "wall_ms": wall, "cost": m["usage"]["estimated_cost_usd"]}\n\nrows = [receipt(e) for e in DATA["experiments"]]\nfor row in rows:\n    print(f'{row["id"]:20} {row["calls"]:4} calls  {row["judgments"]:4} judgments  {row["wall_ms"]:7.1f} ms  USD {row["cost"]:.7f}')\nprint("TOTAL", sum(r["calls"] for r in rows), "calls /", sum(r["judgments"] for r in rows), "judgments")`),
    markdownCell(`## 2. Inspect any experiment\n\nThis prints the exact question text and the first saved inputs/results. Retrieval experiments store their questions in the grid; every other experiment stores a question dictionary.`),
    codeCell(`def inspect_experiment(experiment_id, sample_rows=3):\n    e = next(x for x in DATA["experiments"] if x["id"] == experiment_id)\n    questions = ({row["id"]: row["label"] for row in e["grid"]} if e.get("kind") == "retrieval" else e.get("questions", {}))\n    print("TITLE:", e["title"])\n    print("DESCRIPTION:", e["description"])\n    print("\\nEXACT QUESTIONS:")\n    for key, question in questions.items():\n        print(f"- {key}: {question}")\n    saved_rows = e.get("rows") or e.get("documents") or []\n    print("\\nSAVED INPUT/RESULT SAMPLES:")\n    for row in saved_rows[:sample_rows]:\n        print(json.dumps(row, indent=2)[:2500], "\\n")\n    return e\n\ninspect_experiment("customer-voice")`),
    markdownCell(`## 3. View all ${data.experiments.length} setups`),
    codeCell(`for e in DATA["experiments"]:\n    q = e["grid"] if e.get("kind") == "retrieval" else e.get("questions", {})\n    n_questions = len(q)\n    n_inputs = len(e.get("rows") or e.get("documents") or [])\n    print(f'{e["id"]:20} {n_inputs:3} saved inputs/rows × {n_questions:2} questions')`),
    markdownCell(`## 4. Make one live TypeSafe call\n\nSet \`TYPESAFE_API_KEY\` in your environment. This uses only Python's standard library. Question values can be shorthand Noul strings or complete Choice / Score specifications.`),
    codeCell(`def call_typesafe(document, questions, model="speed_latest"):\n    key = os.environ["TYPESAFE_API_KEY"]\n    typed = {name: ({"type": "noul", "instructions": spec} if isinstance(spec, str) else spec) for name, spec in questions.items()}\n    body = json.dumps({"document": document, "model": model, "questions": typed}).encode()\n    request = urllib.request.Request(\n        "https://api.typesafe.ai/v1/systemone",\n        data=body,\n        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},\n        method="POST",\n    )\n    with urllib.request.urlopen(request) as response:\n        return json.loads(response.read())\n\n# Uncomment to rerun a minimal Choice + Score example:\n# call_typesafe(\n#     "SUBJECT: Contract expires at 3 PM\\nBODY: Please sign or tell us to walk away.",\n#     {\n#       "action": {"type": "choice", "instructions": "What should I do?", "criteria": {"reply_now": "Act immediately", "read_later": "No action today"}},\n#       "urgency": {"type": "score", "instructions": "How urgent is this?", "criteria": ["No action", "Can wait", "Today", "Immediate"]},\n#     },\n# )`),
    markdownCell(`## 5. Rerun the complete lab\n\nThese are the exact project runners. The first runner also uses \`OPENAI_API_KEY\` for the comparison judge. The agent runner needs Claude Headless. The QMD comparison needs QMD 2.8.3 and downloads its local embedding model on first use.`),
    codeCell(`# Run from the extracted source bundle after setting TYPESAFE_API_KEY and OPENAI_API_KEY.\n# subprocess.run(["node", "scripts/run-experiments.mjs"], cwd=ROOT, check=True)\n# subprocess.run(["node", "scripts/run-agent-navigation.mjs"], cwd=ROOT, check=True)\n# subprocess.run(["node", "scripts/merge-agent-navigation.mjs"], cwd=ROOT, check=True)\n# subprocess.run(["node", "scripts/run-qmd-comparison.mjs"], cwd=ROOT, check=True, env={**os.environ, "QMD_BIN": "qmd"})\n# subprocess.run(["node", "scripts/run-ai-checker.mjs", "--reuse"], cwd=ROOT, check=True)\n# subprocess.run(["node", "scripts/run-more-experiments.mjs"], cwd=ROOT, check=True)\n# subprocess.run(["node", "scripts/build-downloads.mjs"], cwd=ROOT, check=True)`),
    markdownCell(`## 6. Check the data files\n\nThe manifest hashes make changes to recorded experiment data visible.`),
    codeCell(`import hashlib\nfor relative, expected in MANIFEST["artifact_sha256"].items():\n    actual = hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()\n    print("PASS" if actual == expected else "FAIL", relative, actual)`),
  ],
  metadata: { kernelspec: { display_name: "Python 3", language: "python", name: "python3" }, language_info: { name: "python", version: "3" } },
  nbformat: 4,
  nbformat_minor: 5,
};

const notebookDir = path.join(ROOT, "notebooks");
const downloadsDir = path.join(ROOT, "public", "downloads");
await mkdir(notebookDir, { recursive: true });
await mkdir(downloadsDir, { recursive: true });
await mkdir(path.join(ROOT, "experiments"), { recursive: true });

const notebookRaw = `${JSON.stringify(notebook, null, 2)}\n`;
await writeFile(path.join(ROOT, "experiments", "RUN_MANIFEST.json"), `${JSON.stringify(manifest, null, 2)}\n`);
await writeFile(path.join(ROOT, "experiments", "REPORT.md"), report);
await writeFile(path.join(notebookDir, "TypeSafe_Parallel_Judgment_Lab.ipynb"), notebookRaw);
await writeFile(path.join(downloadsDir, "typesafe-lab.ipynb"), notebookRaw);
await writeFile(path.join(downloadsDir, "experiments.json"), dataRaw);
await writeFile(path.join(downloadsDir, "experiment-report.md"), report);
await writeFile(path.join(downloadsDir, "RUN_MANIFEST.json"), `${JSON.stringify(manifest, null, 2)}\n`);

console.log(JSON.stringify({ notebook: "notebooks/TypeSafe_Parallel_Judgment_Lab.ipynb", manifest: "experiments/RUN_MANIFEST.json", totals: manifest.totals }, null, 2));
