import { execFile } from "node:child_process";
import { mkdtemp, mkdir, readFile, writeFile } from "node:fs/promises";
import { promisify } from "node:util";
import os from "node:os";
import path from "node:path";
import { performance } from "node:perf_hooks";

const run = promisify(execFile);
const ROOT = process.cwd();
const QMD_BIN = process.env.QMD_BIN ?? "qmd";

function round(value, digits = 3) { return Number(value.toFixed(digits)); }
function mean(values) { return values.reduce((sum, value) => sum + value, 0) / Math.max(values.length, 1); }

function normalizePath(value) {
  return String(value ?? "")
    .replace(/^qmd:\/\/company-brain\//, "")
    .replace(/^.*fixtures\/company-brain\//, "")
    .replace(/^\.\//, "");
}

function parseJsonOutput(stdout) {
  const trimmed = stdout.trim();
  const starts = [trimmed.indexOf("["), trimmed.indexOf("{")].filter((index) => index >= 0);
  if (!starts.length) throw new Error(`QMD did not return JSON: ${trimmed.slice(0, 500)}`);
  return JSON.parse(trimmed.slice(Math.min(...starts)));
}

function normalizeResults(payload) {
  const rows = Array.isArray(payload) ? payload : payload.results ?? payload.matches ?? [];
  return rows.map((row) => ({
    id: normalizePath(row.file ?? row.path ?? row.uri ?? row.document ?? row.source),
    score: round(Number(row.score ?? row.similarity ?? row.rank_score ?? 0), 5),
    title: row.title ?? null,
    excerpt: String(row.snippet ?? row.content ?? row.text ?? "").replace(/\s+/g, " ").slice(0, 190),
  }));
}

function retrievalMetrics(queries) {
  const rows = queries.map((query) => {
    const relevant = new Set(query.relevant);
    const firstIndex = query.top.findIndex((row) => relevant.has(row.id));
    const hitsAt3 = [...relevant].filter((id) => query.top.slice(0, 3).some((row) => row.id === id)).length;
    return { first_rank: firstIndex < 0 ? null : firstIndex + 1, recall_at_3: hitsAt3 / relevant.size };
  });
  return {
    recall_at_3: round(mean(rows.map((row) => row.recall_at_3))),
    mrr: round(mean(rows.map((row) => row.first_rank ? 1 / row.first_rank : 0))),
  };
}

async function qmd(args, env) {
  const started = performance.now();
  const { stdout, stderr } = await run(QMD_BIN, args, { cwd: ROOT, env, maxBuffer: 20 * 1024 * 1024 });
  return { stdout, stderr, wall_ms: round(performance.now() - started, 1) };
}

const dataPath = path.join(ROOT, "public", "experiments.json");
const data = JSON.parse(await readFile(dataPath, "utf8"));
const company = data.experiments.find((experiment) => experiment.id === "company-brain");
if (!company) throw new Error("company-brain experiment is missing");

const qmdRoot = await mkdtemp(path.join(os.tmpdir(), "qmd-company-brain-"));
const configDir = path.join(qmdRoot, "config");
const cacheDir = path.join(qmdRoot, "cache");
await mkdir(configDir, { recursive: true });
await mkdir(cacheDir, { recursive: true });
await writeFile(path.join(configDir, "index.yml"), `global_context: "Synthetic company policies for retrieval evaluation"\ncollections:\n  company-brain:\n    path: ${path.join(ROOT, "fixtures", "company-brain")}\n    pattern: "**/*.md"\n    context:\n      "/": "Company policies and operating documents"\n`);

const env = { ...process.env, QMD_CONFIG_DIR: configDir, XDG_CACHE_HOME: cacheDir, NO_COLOR: "1" };
const versionResult = await qmd(["--version"], env);
const qmdVersion = versionResult.stdout.match(/\d+\.\d+\.\d+/)?.[0] ?? "unknown";
console.log("Indexing company-brain documents with QMD…");
const update = await qmd(["update"], env);
console.log("Generating QMD semantic embeddings…");
const embed = await qmd(["embed", "--timeout", "30"], env);

async function runMethod(command, implementation) {
  const started = performance.now();
  const queries = [];
  for (const query of company.metrics.queries) {
    const result = await qmd([command, query.query, "-n", "5", "-c", "company-brain", "--format", "json"], env);
    queries.push({
      id: query.id,
      query: query.query,
      relevant: query.relevant,
      wall_ms: result.wall_ms,
      top: normalizeResults(parseJsonOutput(result.stdout)).slice(0, 5),
    });
  }
  return {
    implementation,
    wall_ms: round(performance.now() - started, 1),
    mean_query_ms: round(mean(queries.map((query) => query.wall_ms)), 1),
    ...retrievalMetrics(queries),
    queries,
  };
}

console.log("Running QMD keyword queries…");
const keyword = await runMethod("search", `QMD ${qmdVersion} BM25 full-text search`);
console.log("Running QMD semantic queries…");
const semantic = await runMethod("vsearch", `QMD ${qmdVersion} vector semantic search with embeddinggemma-300M`);

const typesafeQueries = company.metrics.queries.map((query) => ({
  id: query.id,
  query: query.query,
  relevant: query.relevant,
  wall_ms: company.measured.wall_ms,
  top: query.top.map((row) => ({ id: row.id, score: row.score, title: company.documents.find((doc) => doc.id === row.id)?.title ?? null, excerpt: company.documents.find((doc) => doc.id === row.id)?.excerpt ?? "" })),
}));
const typesafe = {
  implementation: "TypeSafe speed_latest parallel yes/no judgment over every document",
  wall_ms: company.measured.wall_ms,
  mean_query_ms: company.measured.wall_ms,
  recall_at_3: company.metrics.recall_at_3,
  mrr: company.metrics.mrr,
  queries: typesafeQueries,
};

company.comparison = {
  qmd: {
    version: qmdVersion,
    source: "https://github.com/tobi/qmd",
    index_wall_ms: update.wall_ms,
    embed_wall_ms: embed.wall_ms,
    corpus: "The same 10 markdown documents and 7 human-labeled questions used by TypeSafe.",
  },
  methods: { keyword, semantic, typesafe },
  note: "QMD queries were executed sequentially because each search is a query operation. TypeSafe scored all 10 documents against all 7 questions in one parallel batch. Compare returned files and retrieval quality; the wall times describe different execution shapes.",
};

data.generated_at = new Date().toISOString();
await writeFile(dataPath, `${JSON.stringify(data, null, 2)}\n`);
await writeFile(path.join(ROOT, "experiments", "qmd-company-brain.json"), `${JSON.stringify(company.comparison, null, 2)}\n`);
console.log(JSON.stringify({
  output: "experiments/qmd-company-brain.json",
  qmd: company.comparison.qmd,
  methods: Object.fromEntries(Object.entries(company.comparison.methods).map(([id, method]) => [id, { wall_ms: method.wall_ms, mean_query_ms: method.mean_query_ms, recall_at_3: method.recall_at_3, mrr: method.mrr, first_query_top: method.queries[0].top.slice(0, 3) }])),
}, null, 2));
