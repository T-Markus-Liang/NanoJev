import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";

const root = process.cwd();
const dataPath = path.join(root, "public", "experiments.json");
const experimentPath = path.join(root, "experiments", "agent-navigation.json");
const data = JSON.parse(await readFile(dataPath, "utf8"));
const experiment = JSON.parse(await readFile(experimentPath, "utf8"));
const fixture = JSON.parse(await readFile(path.join(root, "fixtures", "agent-codebase.json"), "utf8"));
const contentByPath = new Map(fixture.files.map((file) => [file.path, file.content]));
experiment.corpus.manifest = experiment.corpus.manifest.map((file) => ({ ...file, content: contentByPath.get(file.path) ?? file.content ?? "" }));
await writeFile(experimentPath, `${JSON.stringify(experiment, null, 2)}\n`);
const without = data.experiments.filter((item) => item.id !== experiment.id);
const codeIndex = without.findIndex((item) => item.id === "code-rag");
without.splice(codeIndex + 1, 0, experiment);
data.experiments = without;
data.generated_at = new Date().toISOString();
await writeFile(dataPath, `${JSON.stringify(data, null, 2)}\n`);
console.log(JSON.stringify({ merged: experiment.id, experiments: data.experiments.length, generated_at: data.generated_at }, null, 2));
