export async function createPayout(request: PayoutRequest) {
  return db.transaction(async (tx) => {
    const existing = await tx.payouts.findByIdempotencyKey(request.idempotencyKey);
    if (existing) return existing;
    return tx.payouts.insert({ ...request, state: "pending" });
  });
}

