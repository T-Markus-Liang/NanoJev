export function publishJob(name: string, payload: unknown) {
  return queue.publish(name, payload, {
    traceparent: activeSpan()?.traceparent,
    correlationId: requestContext.correlationId,
  });
}
// Workers restore both fields before starting their child span.

