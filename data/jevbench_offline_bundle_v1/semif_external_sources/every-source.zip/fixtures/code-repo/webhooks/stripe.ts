export async function stripeWebhook(rawBody: Buffer, signature: string) {
  const event = stripe.webhooks.constructEvent(rawBody, signature, env.STRIPE_SECRET);
  if (await events.wasProcessed(event.id)) return { duplicate: true };
  await queue.publish("stripe-events", event, { retry: { attempts: 8, backoff: "exponential" } });
  await events.markProcessed(event.id);
}

