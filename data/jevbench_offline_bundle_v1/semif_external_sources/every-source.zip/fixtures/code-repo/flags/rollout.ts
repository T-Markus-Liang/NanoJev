export function isInRollout(flag: string, actorId: string, percentage: number) {
  const bucket = stableHash(`${flag}:${actorId}`) % 10_000;
  return bucket < percentage * 100;
}
// Stable hashing keeps an actor in the same cohort across requests and deploys.

