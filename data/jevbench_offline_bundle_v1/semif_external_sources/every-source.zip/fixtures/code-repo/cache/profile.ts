export async function readProfile(userId: string) {
  const key = `profile:${userId}`;
  const hit = await redis.get(key);
  if (hit) return JSON.parse(hit);
  const profile = await db.profiles.find(userId);
  await redis.set(key, JSON.stringify(profile), { ex: 300 });
  return profile;
}

