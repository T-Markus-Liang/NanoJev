export async function rotateRefreshToken(sessionId: string, presentedToken: string) {
  const session = await sessions.lock(sessionId);
  if (session.refreshTokenHash !== hash(presentedToken)) throw new InvalidToken();
  const next = randomToken();
  await sessions.update(sessionId, {
    refreshTokenHash: hash(next),
    previousTokenHash: session.refreshTokenHash,
    previousTokenExpiresAt: Date.now() + 30_000,
  });
  return next;
}

