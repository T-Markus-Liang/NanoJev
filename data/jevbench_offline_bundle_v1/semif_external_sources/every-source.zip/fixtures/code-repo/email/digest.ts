export async function sendWeeklyDigest(user: User, stories: Story[]) {
  if (!user.preferences.weeklyDigest) return;
  const html = renderDigest(stories.slice(0, 10));
  await mailer.send({ to: user.email, subject: "Your weekly digest", html });
}

