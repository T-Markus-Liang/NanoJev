CREATE TABLE ledger_entries (
  id UUID PRIMARY KEY,
  account_id UUID NOT NULL,
  amount_cents BIGINT NOT NULL,
  reversal_of UUID REFERENCES ledger_entries(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- Ledger rows are immutable. Correct mistakes by inserting a reversing entry.
REVOKE UPDATE, DELETE ON ledger_entries FROM app_user;

