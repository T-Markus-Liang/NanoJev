# Vendor security review

All vendors receiving customer data require a security questionnaire, a signed DPA, and a named internal owner. Vendors processing production credentials also require Security approval before procurement. Reviews expire after twelve months.

