# Product launch checklist

Public launches need a rollback plan, an on-call owner, release notes, analytics events, and support enablement. Features touching billing also require Finance sign-off. The launch owner schedules a review 48 hours before release.

