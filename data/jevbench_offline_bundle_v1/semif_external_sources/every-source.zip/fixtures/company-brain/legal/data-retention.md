# Data retention

Customer workspace content is deleted within 30 days of contract termination unless a legal hold applies. Billing records are retained for seven years. Backup copies age out within 90 days and cannot be selectively edited.

