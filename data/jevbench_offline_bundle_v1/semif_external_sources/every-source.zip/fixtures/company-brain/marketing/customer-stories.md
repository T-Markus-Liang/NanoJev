# Customer story approvals

Marketing needs written customer approval before publishing a logo, quote, or case study. Claims about quantified outcomes require source evidence. Drafts involving regulated customers must be reviewed by Legal.

