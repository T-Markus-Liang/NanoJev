# Sales discount authority

Account executives may approve discounts up to 10%. Regional directors may approve up to 20%. Any larger discount, non-standard payment term, or most-favored-nation clause requires Deal Desk and Finance approval.

