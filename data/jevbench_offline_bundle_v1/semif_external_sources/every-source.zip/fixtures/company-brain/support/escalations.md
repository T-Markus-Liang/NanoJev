# Support escalation policy

Security reports go directly to the security queue. Revenue-blocking outages are SEV-1. Billing disputes above $5,000 require Finance. Threats of litigation are escalated to Legal without offering compensation or admitting fault.

