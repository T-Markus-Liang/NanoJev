# Travel and expenses

Employees may book economy airfare and hotels up to $350 per night in major cities. Manager approval is required before booking travel above $2,000 total. Expense reports are due within 30 days of the trip.

