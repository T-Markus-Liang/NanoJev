# Parental leave

Full-time employees receive sixteen weeks of paid parental leave after six months of employment. Leave may be taken continuously or in two blocks during the first year after birth or placement. People Ops needs four weeks notice when possible.

