# Incident response

SEV-1 incidents page the primary on-call and incident commander immediately. Postmortems are due within five business days and must name contributing factors and follow-up owners. Customer communications are coordinated by Support and Legal.

