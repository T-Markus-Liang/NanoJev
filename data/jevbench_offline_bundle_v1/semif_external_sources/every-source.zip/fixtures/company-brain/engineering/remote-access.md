# Production access

Production shell access is time-limited and requires a ticket, manager approval, and phishing-resistant MFA. Shared accounts are prohibited. Emergency access expires after two hours and is reviewed the next business day.

