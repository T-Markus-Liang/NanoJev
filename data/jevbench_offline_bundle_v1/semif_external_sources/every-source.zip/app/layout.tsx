import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TypeSafe // Parallel Judgment Lab",
  description: "Eleven measured TypeSafe experiments with inspectable setups, saved trajectories, retrieval comparisons, and downloadable code.",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  openGraph: {
    title: "What if judgment were parallel?",
    description: "Eleven measured experiments with TypeSafe's typed probability API.",
    type: "website",
    images: [{ url: "/og-v3.png", width: 1743, height: 902, alt: "What if judgment were parallel? Eleven measured TypeSafe experiments." }],
  },
  twitter: {
    card: "summary_large_image",
    title: "What if judgment were parallel?",
    description: "Eleven measured experiments with TypeSafe's typed probability API.",
    images: ["/og-v3.png"],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
