"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Experiment = Record<string, any>;
type Payload = {
  generated_at: string;
  methodology: Record<string, any>;
  experiments: Experiment[];
};

const COPY: Record<string, { label: string; title: string; eyebrow: string; thesis: string; data: string; decision: string; compose: string; limitation: string; take: string }> = {
  "code-rag": {
    label: "Code answer finder", title: "Find the right file for a coding question", eyebrow: "a search box for a codebase",
    thesis: "An engineer asks a normal question. The agent turns it into a yes-or-no check for each file, TypeSafe scores every file at once, and the best match rises to the top.",
    data: "8 files in a small, deliberately fake payments codebase: authentication, payments, webhooks, database rules, feature flags, tracing, and two distractors.",
    decision: "For each of 6 developer questions, which file should an assistant open first?",
    compose: "Sort files by P(the file-level question is true). No answer text is generated.",
    limitation: "This is a clean toy repository. A production test should use a larger repo and human relevance labels.",
    take: "On this small corpus, the correct file ranked first for every question. In ordinary terms: it behaves like very fast semantic search for an agent that needs to decide what to read next.",
  },
  "agent-navigation": {
    label: "Agent navigation race", title: "Watch an agent find the answer with and without TypeSafe", eyebrow: "the same Claude task, two ways",
    thesis: "Two Claude Headless agents receive the same unfamiliar 30-file codebase and the same debugging question. One searches filenames and text; the other asks TypeSafe to score every file before deciding what to open.",
    data: "The same 30-file synthetic TypeScript service for both trials, including authentication, billing, webhooks, caching, search, messaging, and deliberately plausible distractors.",
    decision: "Where is refresh-token rotation and replay protection implemented, and how does it work?",
    compose: "Compare the recorded tool trajectories: time to the target, searches performed, files opened, total answer time, and final correctness.",
    limitation: "This is one run per condition on a synthetic repository. Agent latency and tool choices vary; the trace demonstrates a workflow, not a statistically powered benchmark.",
    take: "Both agents found the right implementation. The TypeSafe-guided agent reached the target sooner, used one retrieval step instead of two search rounds, opened two files instead of four, and finished about eight seconds earlier in this run.",
  },
  "company-brain": {
    label: "Policy answer finder", title: "Find the company policy that answers a question", eyebrow: "instant company search",
    thesis: "An employee asks a normal policy question. Every source receives the same yes-or-no check—‘Does this document answer this question?’—and TypeSafe scores them all at once.",
    data: "10 synthetic company documents covering sales, security, people, engineering, product, legal, and support policies.",
    decision: "Which document or documents should an employee read for each of 7 questions?",
    compose: "Rank documents by relevance probability and show the top three.",
    limitation: "The policy set is synthetic and small; permissioning and stale-document handling are outside this test.",
    take: "The right policy appeared in the top three for every question. The useful edge case was a vendor question that needed both the security review and production-access policies.",
  },
  "judge-grid": {
    label: "Reply quality checker", title: "Check a batch of customer-support replies", eyebrow: "quality control before send",
    thesis: "Six draft replies are checked for grounding, usefulness, promises, secrets, tone, and concision—all in one probability grid.",
    data: "6 synthetic replies to a duplicate-charge complaint, paired with a short support policy and 36 human labels.",
    decision: "Which replies are safe and useful enough to send, and exactly which rule did a weak reply break?",
    compose: "Threshold each probability at 0.5 and compare with human labels; repeat the grid to measure consistency and compare with GPT-5.4 mini.",
    limitation: "Only six intentionally obvious replies were labeled. This is a smoke test, not a full judge calibration.",
    take: "TypeSafe agreed with 32 of 36 labels. GPT agreed more often on this tiny set, but TypeSafe returned the whole grid much faster and with very little repeat variation.",
  },
  "action-firewall": {
    label: "Risky-action stoplight", title: "Stop an AI agent before it does something risky", eyebrow: "a safety check before action",
    thesis: "Before an agent deletes, sends, installs, or publishes, five probabilities decide whether to allow it, ask a person, or block it.",
    data: "10 synthetic actions ranging from reading a config file to deleting remote branches or sharing customer emails.",
    decision: "Allow, require confirmation, or block each proposed action?",
    compose: "A visible code rule combines destruction, authorization, sensitive-data, confirmation, and reversibility probabilities.",
    limitation: "The examples are short and unambiguous. Real agents need surrounding intent, identity, and system state.",
    take: "All 10 actions matched the expected decision. The important design is that TypeSafe supplies signals while the safety policy remains explicit, reviewable code.",
  },
  "vc-diligence": {
    label: "Startup pitch sorter", title: "Match startup pitches to an investment thesis", eyebrow: "a full memo behind every score",
    thesis: "Each company is evaluated against the same long investment memo: fund mandate, preferred signals, risk limits, and lessons from prior investments.",
    data: "One synthetic investment memo plus 8 synthetic startup pitches with varied traction, moats, capital needs, and regulation.",
    decision: "Given this fund’s thesis and history, should it pursue an investment in each company?",
    compose: "Rank the direct P(should invest) signal; keep seven atomic thesis, evidence, moat, feasibility, capital, and risk checks as diagnostics.",
    limitation: "The memo and companies are synthetic, and a probability cannot replace partner diligence, references, or source verification.",
    take: "The shared memo changes this from generic pitch scoring into fund-specific judgment. The direct investment probability drives the ranking; the parallel diagnostics show which part of the thesis each company matches or violates.",
  },
  "ai-checker": {
    label: "AI writing checker", title: "Check an archive for AI writing patterns", eyebrow: "21 style checks per article",
    thesis: "Every public Mike Taylor article receives the same AI-style probabilities, alongside controlled AI-written counterparts.",
    data: "27 public Every posts plus 10 deliberately AI-styled counterparts on matching topics.",
    decision: "Do the controlled counterparts score as more AI-like, and which stylistic tells appear in each article?",
    compose: "Compare the direct P(AI) signal within 10 matched pairs; display 20 additional diagnostic style probabilities.",
    limitation: "Style is not provenance. A high score cannot prove AI wrote a post, and the published set is not verified no-AI ground truth.",
    take: "Every controlled counterpart scored above its paired article on direct P(AI). But averaging the individual style tells failed—the real articles also use polished structure and rhetorical templates. That contradiction is part of the result.",
  },
  "customer-voice": {
    label: "Customer mood triage", title: "Find the angriest and happiest customers", eyebrow: "read the whole support queue",
    thesis: "A support lead sees who is furious, who is delighted, and who needs a human today—without reading every ticket first.",
    data: "24 synthetic support messages covering billing, outages, praise, security, documentation, and routine requests.",
    decision: "Who should support contact first, and which customers are angry, happy, at risk of churn, or blocked?",
    compose: "Combine anger, urgency, churn risk, and need-for-human probabilities into a priority score.",
    limitation: "No real customer data was used. Emotion varies by culture and writing style, so a human still reviews the queue.",
    take: "Maple Labs, Orbit Health, and Birch Media rose to the top of the reply queue. Positive messages also separated cleanly, making the same pass useful for saving praise and testimonials.",
  },
  "ceo-radar": {
    label: "CEO decision radar", title: "Find the decisions that need CEO input", eyebrow: "interrupt the CEO less, but better",
    thesis: "Each complete Slack-style thread is classified by who should own the decision. The CEO queue then ranks the threads where CEO judgment is most valuable.",
    data: "18 synthetic, de-identified Slack-style threads with three messages and an explicit open decision. Every full thread is readable below.",
    decision: "Route each thread to the CEO, leadership team, or functional owner—then order the CEO queue.",
    compose: "Use the Choice probability for ‘CEO’ plus six diagnostic probabilities for strategy, impact, cost, reversibility, and delegability.",
    limitation: "These are synthetic reconstructions inspired by company themes, not raw Slack exports. A real system also needs permissions and fresh organizational context.",
    take: "Company-wide strategy and precedent-setting editorial decisions rise; routine execution with an existing policy stays with functional owners. Expand any result to inspect the full thread behind the route.",
  },
  "inbox-urgency": {
    label: "Inbox reply queue", title: "Find the emails that need a reply today", eyebrow: "turn an inbox into a short queue",
    thesis: "The model reads each full subject and body, chooses a concrete inbox action, and rates urgency on an ordered scale.",
    data: "24 synthetic emails: contracts, receipts, outages, newsletters, legal deadlines, travel confirmations, hiring, and security.",
    decision: "Reply today or safely read later?",
    compose: "Combine a four-way Choice classification, a four-level urgency Score, and three yes/no risk checks into the reply queue.",
    limitation: "This did not connect to a private inbox. Thread history, sender importance, and calendar context are absent.",
    take: "The code-created queue matched all 24 synthetic urgency labels. Contract expiry, trademark deadlines, payroll, renewals, and a deletion request ranked highest.",
  },
  "persona-panel": {
    label: "100-person ad panel", title: "Ask 100 AI personas which ad they would click", eyebrow: "a synthetic focus group in one burst",
    thesis: "One hundred personas each choose among the same three ads. Their full Choice distributions become an overall modeled click-share chart and segment-level winners.",
    data: "100 synthetic personas from a 5 role × 5 AI-maturity × 4 primary-need matrix, shown three Every Agent ads.",
    decision: "Which ad should run, and which angle works for each audience?",
    compose: "Average each ad’s share of the three-way Choice distribution and count the selected ad for every persona.",
    limitation: "Synthetic stated preference is not real click behavior. Validate the winner with an actual ad test.",
    take: "The top chart is the modeled share of preference across all 100 personas—not three unrelated yes/no probabilities. The lower cards retain the ad copy and selected-persona counts.",
  },
};

function money(value: number) {
  if (value < 0.001) return `$${value.toFixed(6)}`;
  return `$${value.toFixed(4)}`;
}

function getExperimentStats(experiment: Experiment) {
  if (experiment.id === "judge-grid") {
    return {
      wall: experiment.typesafe.mean_wall_ms,
      calls: experiment.typesafe.calls_per_grid,
      judgments: experiment.documents.length * Object.keys(experiment.questions).length,
      cost: experiment.typesafe.measured.usage.estimated_cost_usd / experiment.typesafe.repeats,
    };
  }
  if (experiment.id === "agent-navigation") {
    return {
      wall: experiment.typesafe.measured.wall_ms,
      calls: experiment.typesafe.measured.calls,
      judgments: experiment.typesafe.measured.judgments,
      cost: experiment.typesafe.measured.usage.estimated_cost_usd,
    };
  }
  return {
    wall: experiment.measured.wall_ms,
    calls: experiment.measured.calls,
    judgments: experiment.measured.judgments,
    cost: experiment.measured.usage.estimated_cost_usd,
  };
}

function getRevealItems(experiment: Experiment) {
  if (experiment.id === "agent-navigation") return experiment.trials.flatMap((trial: any) => [{ reveal_ms: trial.wall_ms }, ...trial.events.map((event: any) => ({ reveal_ms: event.completed_ms ?? event.at_ms }))]);
  if (experiment.kind === "retrieval") return experiment.grid.flatMap((row: any) => row.cells);
  if (experiment.id === "judge-grid") return [...experiment.typesafe.replay, ...(experiment.external.replay ?? [{ reveal_ms: experiment.external.mean_wall_ms }])];
  return experiment.rows;
}

function getReplayDuration(experiment: Experiment) {
  const stats = getExperimentStats(experiment);
  return Math.max(stats.wall, ...getRevealItems(experiment).map((item: any) => item.reveal_ms ?? 0));
}

function getReplayProgress(experiment: Experiment, elapsed: number) {
  if (experiment.id === "agent-navigation") {
    const [manual, assisted] = experiment.trials;
    const manualDone = manual.events.filter((event: any) => (event.completed_ms ?? event.at_ms) <= elapsed).length;
    const assistedDone = assisted.events.filter((event: any) => (event.completed_ms ?? event.at_ms) <= elapsed).length;
    return {
      returnedCalls: manualDone + assistedDone,
      totalCalls: manual.events.length + assisted.events.length,
      returnedJudgments: assistedDone,
      totalJudgments: assisted.events.length,
      label: `Manual ${manualDone}/${manual.events.length} steps · TypeSafe-guided ${assistedDone}/${assisted.events.length}`,
    };
  }
  if (experiment.id === "judge-grid") {
    const outputs = experiment.documents.map((document: any) => document.id);
    const returnedTypeSafe = outputs.filter((output: string) => experiment.typesafe.replay.some((cell: any) => cell.output === output && cell.reveal_ms <= elapsed)).length;
    const returnedExternal = elapsed >= experiment.external.mean_wall_ms ? experiment.external.calls_per_grid : 0;
    return {
      returnedCalls: returnedTypeSafe,
      totalCalls: experiment.typesafe.calls_per_grid,
      returnedJudgments: returnedTypeSafe * Object.keys(experiment.questions).length,
      totalJudgments: experiment.documents.length * Object.keys(experiment.questions).length,
      label: `TypeSafe ${returnedTypeSafe}/${experiment.typesafe.calls_per_grid} calls · ${experiment.external.model} ${returnedExternal}/${experiment.external.calls_per_grid}`,
    };
  }
  if (experiment.kind === "retrieval") {
    const completedDocuments = experiment.documents.filter((document: any) => experiment.grid[0].cells.find((cell: any) => cell.document === document.id)?.reveal_ms <= elapsed).length;
    return {
      returnedCalls: completedDocuments,
      totalCalls: experiment.documents.length,
      returnedJudgments: completedDocuments * experiment.grid.length,
      totalJudgments: experiment.documents.length * experiment.grid.length,
      label: `${completedDocuments}/${experiment.documents.length} calls returned · ${completedDocuments * experiment.grid.length}/${experiment.documents.length * experiment.grid.length} judgments`,
    };
  }
  const completedRows = (experiment.rows ?? []).filter((row: any) => row.reveal_ms <= elapsed).length;
  const questionCount = Object.keys(experiment.questions ?? {}).length;
  return {
    returnedCalls: completedRows,
    totalCalls: experiment.rows.length,
    returnedJudgments: completedRows * questionCount,
    totalJudgments: experiment.rows.length * questionCount,
    label: `${completedRows}/${experiment.rows.length} calls returned · ${completedRows * questionCount}/${experiment.rows.length * questionCount} judgments`,
  };
}

function getQuestionEntries(experiment: Experiment): [string, string][] {
  if (experiment.id === "agent-navigation") return [[experiment.task.id, experiment.task.prompt]];
  if (experiment.kind === "retrieval") return experiment.grid.map((row: any) => [row.id, row.question ?? row.label]);
  return Object.entries(experiment.questions ?? {}).map(([key, value]: any) => [key, typeof value === "string" ? value : value.instructions]);
}

function getInputItems(experiment: Experiment) {
  if (experiment.id === "agent-navigation") return experiment.corpus.manifest.map((item: any) => ({ id: item.path, label: item.path, text: item.content ?? item.excerpt }));
  if (experiment.documents) return experiment.documents.map((item: any) => ({ id: item.id, label: item.title ?? item.id, text: item.document ?? item.excerpt ?? item.response ?? "" }));
  return (experiment.rows ?? []).map((item: any) => ({ id: item.id, label: item.label ?? item.name ?? item.title ?? item.subject ?? item.id, text: item.document ?? item.body ?? item.text ?? item.excerpt ?? "" }));
}

function primitiveName(spec: any) {
  if (!spec || typeof spec === "string") return "Noul";
  return spec.type === "choice" ? "Choice" : spec.type === "score" ? "Score" : String(spec.type ?? "Noul");
}

function primitiveSummary(experiment: Experiment) {
  if (experiment.id === "agent-navigation") return `One Noul relevance question was applied to all ${experiment.corpus.files} files by the supplied CLI.`;
  if (experiment.kind === "retrieval") return `${getQuestionEntries(experiment).length} file-level yes/no questions were sent in parallel.`;
  const counts = Object.values(experiment.questions ?? {}).reduce((acc: Record<string, number>, spec: any) => {
    const name = primitiveName(spec);
    acc[name] = (acc[name] ?? 0) + 1;
    return acc;
  }, {});
  return `${Object.entries(counts).map(([name, count]) => `${count} ${name}`).join(" + ")} question${Object.keys(experiment.questions ?? {}).length === 1 ? " was" : "s were"} sent together for each item.`;
}

function probabilityClass(value: number) {
  if (value >= 0.75) return "prob-high";
  if (value >= 0.45) return "prob-mid";
  if (value >= 0.2) return "prob-low";
  return "prob-zero";
}

function average(values: number[]) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

function median(values: number[]) {
  if (!values.length) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
      {sub ? <small>{sub}</small> : null}
    </div>
  );
}

function SetupPanel({ experiment }: { experiment: Experiment }) {
  const copy = COPY[experiment.id];
  const questions = getQuestionEntries(experiment);
  const inputs = getInputItems(experiment);
  const stats = getExperimentStats(experiment);
  const receiptCalls = experiment.id === "judge-grid" ? experiment.typesafe.measured.calls : stats.calls;
  const receiptJudgments = experiment.id === "judge-grid" ? experiment.typesafe.measured.judgments : stats.judgments;
  return (
    <section className="setup-panel" aria-label="How this test was run">
      <div className="setup-heading">
        <p className="eyebrow">experiment design</p>
        <h3>What went in, what we asked, and how the score became a decision.</h3>
      </div>
      <div className="setup-steps">
        <div><span>01 · Input</span><strong>{copy.data}</strong></div>
        <div><span>02 · TypeSafe call</span><strong>{primitiveSummary(experiment)}</strong></div>
        <div><span>03 · Decision code</span><strong>{copy.compose}</strong></div>
      </div>
      <div className="setup-details">
        {experiment.id === "agent-navigation" ? (
          <details open>
            <summary>See the controlled agent setup <i>+</i></summary>
            <div className="agent-methodology">
              <p><strong>Held constant</strong><span>{experiment.methodology.model_control}</span></p>
              <p><strong>Manual condition</strong><span>{experiment.methodology.baseline}</span></p>
              <p><strong>TypeSafe condition</strong><span>{experiment.methodology.assisted}</span></p>
              <p><strong>Correctness rule</strong><span>The answer had to name {experiment.task.target} and at least three expected implementation symbols.</span></p>
            </div>
          </details>
        ) : null}
        {experiment.context?.text ? (
          <details className="shared-context">
            <summary>Read the shared investment memo <i>+</i></summary>
            <div className="context-document">
              <strong>{experiment.context.name}</strong>
              <small>{experiment.context.note}</small>
              <pre>{experiment.context.text}</pre>
            </div>
          </details>
        ) : null}
        <details>
          <summary>See all {inputs.length} input items <i>+</i></summary>
          <div className="input-list">
            {inputs.map((item: any) => (
              <details className="input-item" key={item.id}>
                <summary><code>{item.id}</code><span>{item.label}</span><i>read full input +</i></summary>
                {item.text ? <pre>{item.text}</pre> : <p>No source text stored.</p>}
              </details>
            ))}
          </div>
        </details>
        <details>
          <summary>See the exact {questions.length} questions <i>+</i></summary>
          <ol className="question-list">
            {questions.map(([key, question]) => <li key={key}><code>{key}</code><span>{question}</span><em>{primitiveName(experiment.questions?.[key])}</em></li>)}
          </ol>
        </details>
        <details>
          <summary>Performance and cost <i>+</i></summary>
          <div className="receipt">
            <span>Model<strong>speed_latest</strong></span>
            <span>API calls<strong>{receiptCalls}</strong></span>
            <span>Judgments<strong>{receiptJudgments}</strong></span>
            <span>{experiment.id === "agent-navigation" ? "TypeSafe search time" : "Measured wall time"}<strong>{stats.wall.toFixed(1)} ms</strong></span>
            <span>Estimated spend<strong>{money(stats.cost)}</strong></span>
            <span>Results data<strong><a href="/downloads/experiments.json" download>JSON ↘</a></strong></span>
          </div>
        </details>
      </div>
      <p className="limitation"><strong>Limitations:</strong> {copy.limitation}</p>
    </section>
  );
}

function ReplayHeader({ experiment, playing, elapsed, duration, onReplay }: any) {
  const progress = Math.min(100, (elapsed / Math.max(duration, 1)) * 100);
  const resultProgress = getReplayProgress(experiment, elapsed);
  const label = experiment.id === "judge-grid" ? "Recorded race · TypeSafe vs GPT-5.4 mini" : experiment.id === "agent-navigation" ? "Recorded race · Claude manual vs Claude + TypeSafe" : "Recorded run · speed_latest";
  return (
    <div className="replay-header">
      <div>
        <p className="micro-label">{label}</p>
        <div className="time-readout"><span>{Math.min(elapsed, duration).toFixed(0)}</span> ms</div>
      </div>
      <div className="replay-progress">
        <div className="replay-track" aria-hidden="true"><i style={{ width: `${progress}%` }} /></div>
        <p className="replay-tally"><span>{resultProgress.label}</span><em>1× saved timing</em></p>
      </div>
      <button className="replay-button" onClick={onReplay} aria-label={`Replay ${experiment.title}`}>
        <span className={playing ? "pulse-dot active" : "pulse-dot"} />
        {playing ? "Running" : "Replay"}
      </button>
    </div>
  );
}

function RetrievalGrid({ experiment, elapsed }: any) {
  const docs = experiment.documents;
  return (
    <div className="grid-scroll">
      <div className="rag-grid" style={{ gridTemplateColumns: `minmax(230px, 1.5fr) repeat(${docs.length}, minmax(68px, 1fr))` }}>
        <div className="corner-label">yes/no question ↓ / source →</div>
        {docs.map((doc: any) => <div className="column-label" key={doc.id} title={doc.id}>{doc.id.replace(/\.(ts|sql|md)$/, "")}</div>)}
        {experiment.grid.map((row: any) => (
          <div className="contents-row" key={row.id}>
            <div className="query-label">{row.label}</div>
            {row.cells.map((cell: any) => {
              const visible = elapsed >= cell.reveal_ms;
              return (
                <div
                  key={`${row.id}-${cell.document}`}
                  className={`prob-cell ${visible ? probabilityClass(cell.value) : "pending"} ${cell.relevant ? "ground-truth" : ""}`}
                  aria-label={`${cell.document}: ${visible ? cell.value.toFixed(2) : "pending"}${cell.relevant ? ", ground truth" : ""}`}
                >
                  {visible ? cell.value.toFixed(2) : "·"}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

function RetrievalResults({ experiment, elapsed }: any) {
  const complete = elapsed >= getReplayDuration(experiment);
  return (
    <div className="result-strip">
      <div><span>TypeSafe Recall@1</span><strong>{complete ? `${Math.round(experiment.metrics.recall_at_1 * 100)}%` : "—"}</strong></div>
      <div><span>Recall@3</span><strong>{complete ? `${Math.round(experiment.metrics.recall_at_3 * 100)}%` : "—"}</strong></div>
      <div><span>MRR</span><strong>{complete ? experiment.metrics.mrr.toFixed(2) : "—"}</strong></div>
      <div className="muted-result"><span>BM25 Recall@1</span><strong>{complete ? `${Math.round(experiment.bm25.recall_at_1 * 100)}%` : "—"}</strong></div>
    </div>
  );
}

function JudgeMatrix({ experiment, elapsed, system }: any) {
  const questionKeys = Object.keys(experiment.questions);
  const isTypeSafe = system === "typesafe";
  const source = isTypeSafe ? experiment.typesafe : experiment.external;
  const cells = isTypeSafe ? source.replay : (source.replay ?? source.cells);
  const cellMap = new Map(cells.map((cell: any) => [`${cell.output}:${cell.question}`, cell]));
  const completionMs = isTypeSafe
    ? Math.max(source.mean_wall_ms, ...source.replay.map((cell: any) => cell.reveal_ms))
    : source.replay ? Math.max(source.mean_wall_ms, ...source.replay.map((cell: any) => cell.reveal_ms)) : source.mean_wall_ms;
  const complete = elapsed >= completionMs;
  return (
    <section className={`judge-panel ${complete ? "complete" : "running"}`} aria-label={`${isTypeSafe ? "TypeSafe speed_latest" : source.model} replay`}>
      <header>
        <div><span>{isTypeSafe ? "TypeSafe" : "General LLM"}</span><strong>{isTypeSafe ? "speed_latest" : source.model}</strong></div>
        <div className="judge-clock"><span>{Math.min(elapsed, completionMs).toFixed(0)} ms</span><i>{complete ? "complete" : "running"}</i></div>
      </header>
      <div className="grid-scroll">
        <div className="judge-grid" style={{ gridTemplateColumns: `minmax(145px, 1.2fr) repeat(${questionKeys.length}, minmax(85px, 1fr))` }}>
          <div className="corner-label">candidate ↓ / check →</div>
          {questionKeys.map((key) => <div className="column-label" key={key}>{key.replaceAll("_", " ")}</div>)}
          {experiment.documents.map((doc: any) => (
            <div className="contents-row" key={doc.id}>
              <div className="query-label candidate-label">{doc.id.replaceAll("_", " ")}</div>
              {questionKeys.map((key) => {
                const cell: any = cellMap.get(`${doc.id}:${key}`);
                const visible = isTypeSafe || source.replay ? elapsed >= cell.reveal_ms : complete;
                const agrees = (cell.value >= 0.5 ? 1 : 0) === cell.expected;
                return (
                  <div key={key} className={`prob-cell ${visible ? probabilityClass(cell.value) : "pending"} ${visible && !agrees ? "miss" : ""}`}>
                    {visible ? cell.value.toFixed(2) : "·"}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function JudgeGrid({ experiment, elapsed }: any) {
  const speedup = experiment.external.mean_wall_ms / experiment.typesafe.mean_wall_ms;
  const typesafeCompletion = Math.max(experiment.typesafe.mean_wall_ms, ...experiment.typesafe.replay.map((cell: any) => cell.reveal_ms));
  const externalCompletion = experiment.external.mean_wall_ms;
  const raceDuration = Math.max(typesafeCompletion, externalCompletion);
  const typesafeWidth = Math.min(elapsed, typesafeCompletion) / raceDuration * 100;
  const externalWidth = Math.min(elapsed, externalCompletion) / raceDuration * 100;
  return (
    <>
      <div className="judge-race">
        <JudgeMatrix experiment={experiment} elapsed={elapsed} system="typesafe" />
        <JudgeMatrix experiment={experiment} elapsed={elapsed} system="external" />
      </div>
      <div className="judge-compare">
        <div className="compare-row">
          <span>TypeSafe</span><div className="compare-bar"><i style={{ width: `${typesafeWidth}%` }} /></div><strong>{Math.min(elapsed, typesafeCompletion).toFixed(0)} ms</strong>
        </div>
        {experiment.external.status === "measured" ? (
          <div className="compare-row external">
            <span>{experiment.external.model}</span><div className="compare-bar"><i style={{ width: `${externalWidth}%` }} /></div><strong>{Math.min(elapsed, externalCompletion).toFixed(0)} ms</strong>
          </div>
        ) : null}
        <p><strong>{speedup.toFixed(1)}× faster in these measured runs.</strong> TypeSafe replays the first recorded grid at its saved row timings. GPT-5.4 mini reveals its mean probability grid at the measured {experiment.external.repeats}-run average completion time because its original row-level timings were not retained.</p>
      </div>
    </>
  );
}

function FirewallRows({ experiment, elapsed }: any) {
  return (
    <div className="action-list">
      {experiment.rows.map((row: any) => {
        const visible = elapsed >= row.reveal_ms;
        return (
          <div className={`action-row ${visible ? "visible" : "pending-row"}`} key={row.id}>
            <span className="action-name">{row.id.replaceAll("_", " ")}</span>
            <div className="signal-dots" aria-label={visible ? Object.entries(row.signals).map(([key, value]) => `${key}: ${value}`).join(", ") : "pending"}>
              {Object.entries(row.signals).map(([key, value]: any) => <i key={key} title={`${key}: ${value}`} style={{ opacity: visible ? Math.max(.12, value) : .08 }} />)}
            </div>
            <span className={`decision ${visible ? row.decision : "waiting"}`}>{visible ? row.decision : "waiting"}</span>
          </div>
        );
      })}
    </div>
  );
}

function VCRows({ experiment, elapsed }: any) {
  return (
    <div className="vc-list">
      {experiment.rows.map((row: any, index: number) => {
        const visible = elapsed >= row.reveal_ms;
        return (
          <div className={`vc-row ${visible ? "visible" : "pending-row"}`} key={row.id}>
            <span className="rank">{String(index + 1).padStart(2, "0")}</span>
            <div className="company"><strong>{row.name}</strong><span>{row.text}</span></div>
            <div className="score-line"><i style={{ width: visible ? `${row.composite * 100}%` : "0%" }} /></div>
            <strong className="composite">{visible ? row.composite.toFixed(2) : "—"}</strong>
            <span className={`decision ${visible ? row.decision : "waiting"}`}>{visible ? row.decision : "waiting"}</span>
          </div>
        );
      })}
    </div>
  );
}

function AICheckerGrid({ experiment, elapsed }: any) {
  const questionKeys = Object.keys(experiment.questions);
  return (
    <div className="ai-grid-wrap">
      <div className="ai-legend">
        <span><i className="published-dot" /> Published Every post</span>
        <span><i className="synthetic-dot" /> Controlled AI-style counterpart</span>
        <span>Cell = P(yes)</span>
      </div>
      <div className="grid-scroll ai-grid-scroll">
        <div className="ai-grid" style={{ gridTemplateColumns: `minmax(260px, 1.7fr) repeat(${questionKeys.length}, minmax(62px, 1fr))` }}>
          <div className="corner-label">post ↓ / pattern check →</div>
          {questionKeys.map((key) => <div className="column-label" key={key}>{key.replaceAll("_", " ")}</div>)}
          {experiment.rows.map((row: any) => {
            const visible = elapsed >= row.reveal_ms;
            return (
              <div className="contents-row" key={row.id}>
                <a className={`query-label ai-post-label ${row.cohort}`} href={row.url} target="_blank" rel="noreferrer" title={row.title}>
                  <i />
                  <span>{row.title.replace(/^Controlled AI-style counterpart:\s*/, "")}</span>
                </a>
                {questionKeys.map((key) => {
                  const value = row.signals[key];
                  return (
                    <div key={`${row.id}-${key}`} className={`prob-cell ${visible ? probabilityClass(value) : "pending"}`} title={`${key.replaceAll("_", " ")}: ${value.toFixed(2)}`}>
                      {visible ? value.toFixed(2) : "·"}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function MatrixAnswer({ experiment, row, questionKey, visible }: any) {
  if (!visible) return <div className="prob-cell pending">·</div>;
  const spec = experiment.questions[questionKey];
  const answer = row.typed_answers?.[questionKey];
  if (typeof spec === "object" && spec.type === "choice") {
    const selected = answer?.choice ?? "—";
    const probability = answer?.probabilities?.[selected] ?? 0;
    return <div className={`prob-cell typed-cell choice-cell ${probabilityClass(probability)}`} title={`${selected}: ${probability.toFixed(2)} · confidence ${answer?.confidence?.toFixed(2) ?? "—"}`}><strong>{selected.replaceAll("_", " ")}</strong><small>{probability.toFixed(2)}</small></div>;
  }
  if (typeof spec === "object" && spec.type === "score") {
    const score = answer?.score ?? 0;
    const max = Math.max(Object.keys(answer?.legend ?? {}).length - 1, 1);
    return <div className={`prob-cell typed-cell score-cell ${probabilityClass(score / max)}`} title={`${score.toFixed(2)} on a 0–${max} scale · confidence ${answer?.confidence?.toFixed(2) ?? "—"}`}><strong>{score.toFixed(1)}</strong><small>/ {max}</small></div>;
  }
  const value = row.signals[questionKey];
  return <div className={`prob-cell ${probabilityClass(value)}`} title={`${questionKey.replaceAll("_", " ")}: ${value.toFixed(2)}`}>{value.toFixed(2)}</div>;
}

function PersonaShareChart({ experiment, elapsed }: any) {
  const visibleRows = experiment.rows.filter((row: any) => elapsed >= row.reveal_ms);
  const shares = Object.fromEntries(["A", "B", "C"].map((ad) => [ad, visibleRows.length
    ? visibleRows.reduce((sum: number, row: any) => sum + row.choice_probabilities[ad], 0) / visibleRows.length
    : 0]));
  return (
    <section className="persona-share" aria-label="Overall modeled click share">
      <header><div><span>Overall modeled click share</span><strong>{visibleRows.length} / 100 personas classified</strong></div><p>One three-way Choice per persona; shares total 100%.</p></header>
      <div className="share-bars">
        {(["A", "B", "C"] as const).map((ad) => <div key={ad}><b>Ad {ad}</b><i><span style={{ width: `${shares[ad] * 100}%` }} /></i><strong>{Math.round(shares[ad] * 100)}%</strong></div>)}
      </div>
    </section>
  );
}

function DecisionMatrix({ experiment, elapsed }: any) {
  const questionKeys = Object.keys(experiment.questions);
  return (
    <>
      {experiment.id === "persona-panel" ? <PersonaShareChart experiment={experiment} elapsed={elapsed} /> : null}
      <div className="grid-scroll decision-grid-scroll">
        <div className="decision-grid" style={{ gridTemplateColumns: `minmax(260px, 1.7fr) repeat(${questionKeys.length}, minmax(92px, 1fr))` }}>
          <div className="corner-label">item ↓ / question →</div>
          {questionKeys.map((key) => <div className="column-label" key={key}>{key.replaceAll("_", " ")} · {primitiveName(experiment.questions[key])}</div>)}
          {experiment.rows.map((row: any) => {
            const visible = elapsed >= row.reveal_ms;
            return (
              <div className="contents-row" key={row.id}>
                <div className="query-label matrix-label" title={row.document ?? row.text ?? row.label}>{row.label ?? row.subject ?? row.id}</div>
                {questionKeys.map((key) => <MatrixAnswer key={`${row.id}-${key}`} experiment={experiment} row={row} questionKey={key} visible={visible} />)}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

function RankedList({ title, rows }: { title: string; rows: any[] }) {
  return (
    <div className="ranked-list">
      <span>{title}</span>
      {!rows.length ? <p className="results-pending">Waiting for completed calls…</p> : null}
      {rows.slice(0, 5).map((row, index) => <div key={row.id}><i>{index + 1}</i><strong>{row.label}</strong><code>{row.value.toFixed(2)}</code></div>)}
    </div>
  );
}

function DecisionResults({ experiment, elapsed }: { experiment: Experiment; elapsed: number }) {
  const rows = experiment.rows.filter((row: any) => row.reveal_ms <= elapsed);
  if (experiment.id === "customer-voice") return (
    <div className="application-results three-col">
      <RankedList title={`Reply first · ${rows.length}/${experiment.rows.length} returned`} rows={[...rows].sort((a: any, b: any) => b.priority - a.priority).map((row: any) => ({ ...row, value: row.priority }))} />
      <RankedList title="Most angry" rows={[...rows].sort((a: any, b: any) => b.anger_score - a.anger_score).map((row: any) => ({ ...row, value: row.anger_score }))} />
      <RankedList title="Happiest" rows={[...rows].sort((a: any, b: any) => b.happiness_score - a.happiness_score).map((row: any) => ({ ...row, value: row.happiness_score }))} />
    </div>
  );
  if (experiment.id === "ceo-radar") {
    const counts = Object.fromEntries(["ceo", "leadership_team", "functional_owner"].map((owner) => [owner, rows.filter((row: any) => row.owner === owner).length]));
    return <div className="application-results">
      <div className="routing-summary">
        <span><strong>{counts.ceo}</strong>CEO</span>
        <span><strong>{counts.leadership_team}</strong>Leadership team</span>
        <span><strong>{counts.functional_owner}</strong>Functional owner</span>
      </div>
      <div className="source-review-list">
        <h4>CEO review queue · {rows.length}/{experiment.rows.length} threads returned</h4>
        {!rows.length ? <p className="results-pending">Waiting for completed calls…</p> : null}
        {[...rows].sort((a: any, b: any) => b.ceo_probability - a.ceo_probability).map((row: any) => (
          <details key={row.id} className={row.owner === "ceo" ? "routed-ceo" : ""}>
            <summary><span>#{row.channel}</span><strong>{row.label}</strong><em>{row.owner.replaceAll("_", " ")} · {Math.round(row.ceo_probability * 100)}% CEO</em></summary>
            <pre>{row.document}</pre>
          </details>
        ))}
      </div>
    </div>;
  }
  if (experiment.id === "inbox-urgency") {
    const correct = rows.filter((row: any) => row.correct).length;
    return <>
      <div className="result-strip two-up">
        <div><span>Synthetic-label agreement</span><strong>{rows.length ? `${Math.round(correct / rows.length * 100)}%` : "—"}</strong></div>
        <div><span>Reply-today queue</span><strong>{rows.filter((row: any) => row.predicted).length}</strong></div>
      </div>
      <div className="application-results">
        <div className="source-review-list">
          <h4>Inbox queue · {rows.length}/{experiment.rows.length} emails returned</h4>
          {!rows.length ? <p className="results-pending">Waiting for completed calls…</p> : null}
          {[...rows].sort((a: any, b: any) => b.priority - a.priority).map((row: any) => (
            <details key={row.id} className={row.predicted ? "reply-today" : ""}>
              <summary><span>{row.action.replaceAll("_", " ")}</span><strong>{row.subject}</strong><em>urgency {row.urgency_score.toFixed(1)} / 3</em></summary>
              <pre>{row.document}</pre>
            </details>
          ))}
        </div>
      </div>
    </>;
  }
  if (experiment.id === "persona-panel") {
    const averages = Object.fromEntries(["A", "B", "C"].map((ad) => [ad, average(rows.map((row: any) => row.choice_probabilities[ad]))]));
    const wins = Object.fromEntries(["A", "B", "C"].map((ad) => [ad, rows.filter((row: any) => row.winner === ad).length]));
    const winner = rows.length ? Object.entries(averages).sort((a: any, b: any) => b[1] - a[1])[0][0] : null;
    return <div className="ad-results">
      {(["A", "B", "C"] as const).map((ad) => (
        <div className={winner === ad ? "winner" : ""} key={ad}>
          <span>Ad {ad}{winner === ad ? " · current leader" : ""}</span>
          <p>{experiment.metrics.ads[ad]}</p>
          <strong>{rows.length ? `${Math.round(averages[ad] * 100)}%` : "—"} <small>modeled click share</small></strong>
          <code>{wins[ad]} / {rows.length} returned personas</code>
        </div>
      ))}
    </div>;
  }
  return null;
}

function ProgressiveAccuracyStrip({ experiment, elapsed }: any) {
  const rows = experiment.rows.filter((row: any) => row.reveal_ms <= elapsed);
  const correct = rows.filter((row: any) => row.correct).length;
  return (
    <div className="result-strip two-up">
      <div><span>Human-label agreement</span><strong>{rows.length ? `${Math.round(correct / rows.length * 100)}%` : "—"}</strong></div>
      <div><span>Typed signals returned</span><strong>{rows.length * Object.keys(experiment.questions).length}</strong></div>
    </div>
  );
}

function AICheckerResults({ experiment, elapsed }: any) {
  const rows = experiment.rows.filter((row: any) => row.reveal_ms <= elapsed);
  const published = rows.filter((row: any) => row.cohort === "published");
  const controlled = rows.filter((row: any) => row.cohort === "controlled_ai");
  const publishedBySource = new Map(published.map((row: any) => [row.source_id, row]));
  const pairs = controlled.flatMap((controlledRow: any) => {
    const publishedRow: any = publishedBySource.get(controlledRow.source_id);
    return publishedRow ? [{ published: publishedRow.model_ai_probability, controlled: controlledRow.model_ai_probability }] : [];
  });
  const separated = pairs.filter((pair: any) => pair.controlled > pair.published).length;
  const meanLift = average(pairs.map((pair: any) => pair.controlled - pair.published));
  return (
    <>
      <div className="result-strip ai-results">
        <div><span>Published median P(AI)</span><strong>{published.length ? median(published.map((row: any) => row.model_ai_probability)).toFixed(2) : "—"}</strong></div>
        <div><span>Controlled median P(AI)</span><strong>{controlled.length ? median(controlled.map((row: any) => row.model_ai_probability)).toFixed(2) : "—"}</strong></div>
        <div><span>Paired directional separation</span><strong>{pairs.length ? `${Math.round(separated / pairs.length * 100)}%` : "—"}</strong></div>
        <div><span>Mean paired lift</span><strong>{pairs.length ? `${meanLift >= 0 ? "+" : ""}${meanLift.toFixed(2)}` : "—"}</strong></div>
      </div>
      <p className="checker-caveat">{pairs.length}/{experiment.metrics.pairs.length} matched pairs returned. {experiment.methodology.caveat} Published text is a voice baseline, not verified no-AI ground truth.</p>
    </>
  );
}

function AgentTrajectory({ experiment, elapsed }: any) {
  return (
    <div className="trajectory">
      <div className="trajectory-task">
        <span>Agent task</span>
        <strong>{experiment.task.prompt}</strong>
      </div>
      <div className="trajectory-lanes">
        {experiment.trials.map((trial: any) => {
          const completed = elapsed >= trial.wall_ms;
          const visibleEvents = trial.events.filter((event: any) => event.at_ms <= elapsed);
          const liveClock = Math.min(elapsed, trial.wall_ms);
          const isAssisted = trial.id === "typesafe-rag";
          const searchEvent = trial.events.find((event: any) => event.kind === "typesafe_search");
          const showRanking = isAssisted && searchEvent && (searchEvent.completed_ms ?? Infinity) <= elapsed;
          return (
            <article className={`trajectory-lane ${isAssisted ? "assisted" : "manual"}`} key={trial.id}>
              <header>
                <div><span>{isAssisted ? "Claude + TypeSafe CLI" : "Claude + ordinary shell"}</span><strong>{trial.label}</strong></div>
                <div className="trajectory-clock"><strong>{(liveClock / 1000).toFixed(1)}s</strong><small>{completed ? "answer complete" : "running"}</small></div>
              </header>
              <div className="trajectory-track"><i style={{ width: `${Math.min(100, elapsed / trial.wall_ms * 100)}%` }} /></div>
              <div className="trajectory-events">
                {visibleEvents.length ? visibleEvents.map((event: any, index: number) => {
                  const eventDone = (event.completed_ms ?? Infinity) <= elapsed;
                  return (
                    <div className={`trajectory-event ${event.kind} ${eventDone ? "done" : "active"}`} key={event.id}>
                      <time>{(event.at_ms / 1000).toFixed(1)}s</time>
                      <span>{String(index + 1).padStart(2, "0")}</span>
                      <div><strong>{event.kind === "typesafe_search" ? "Score all 30 files in parallel" : event.label || event.kind}</strong><code>{event.command}</code>{eventDone && event.duration_ms ? <small>returned in {(event.duration_ms / 1000).toFixed(2)}s</small> : <small>waiting for result…</small>}</div>
                    </div>
                  );
                }) : <p className="trajectory-thinking">Claude is deciding what to do first…</p>}
              </div>
              {showRanking ? (
                <div className="trajectory-ranking">
                  <span>TypeSafe returned</span>
                  {experiment.typesafe.ranking.slice(0, 3).map((row: any, index: number) => <div key={row.file}><b>#{index + 1}</b><code>{row.file}</code><strong>{row.score.toFixed(2)}</strong></div>)}
                </div>
              ) : null}
              {completed ? (
                <footer className="trajectory-outcome">
                  <strong>{trial.correct ? "Correct answer" : "Incorrect answer"}</strong>
                  <span>{trial.search_rounds} retrieval step{trial.search_rounds === 1 ? "" : "s"} · {trial.files_opened} files opened · ${(trial.wall_ms / 1000).toFixed(1)}s total</span>
                </footer>
              ) : null}
            </article>
          );
        })}
      </div>
    </div>
  );
}

function CompanyBrainComparison({ experiment }: any) {
  const methods = experiment.comparison?.methods;
  const [queryId, setQueryId] = useState(experiment.grid[0].id);
  if (!methods) return null;
  const query = experiment.metrics.queries.find((item: any) => item.id === queryId);
  const methodOrder = [
    ["keyword", "QMD keyword", "Exact words"],
    ["semantic", "QMD semantic", "Similar meaning"],
    ["typesafe", "TypeSafe", "Does this answer it?"],
  ];
  return (
    <section className="retrieval-comparison" aria-labelledby="retrieval-comparison-title">
      <div className="comparison-heading">
        <div><p className="eyebrow">same question, three retrieval methods</p><h3 id="retrieval-comparison-title">See exactly which files come back.</h3></div>
        <p>Keyword search matches terms. Semantic search matches meaning. TypeSafe asks every document whether it answers the question. All three used the same ten files.</p>
      </div>
      <div className="comparison-query-picker" aria-label="Choose a company question">
        {experiment.metrics.queries.map((item: any, index: number) => <button type="button" key={item.id} className={item.id === queryId ? "selected" : ""} onClick={() => setQueryId(item.id)}><span>{String(index + 1).padStart(2, "0")}</span>{item.query}</button>)}
      </div>
      <div className="retrieval-methods">
        {methodOrder.map(([id, label, plain]) => {
          const method = methods[id];
          const result = method.queries.find((item: any) => item.id === queryId);
          return (
            <article key={id} className={`retrieval-method ${id}`}>
              <header><div><span>{plain}</span><strong>{label}</strong></div><div><b>{Math.round(method.recall_at_3 * 100)}%</b><small>Recall@3</small></div></header>
              <div className="retrieval-method-meta"><span>{id === "typesafe" ? `${method.wall_ms.toFixed(0)} ms full 7×10 batch` : `${result.wall_ms.toFixed(0)} ms this query`}</span><span>MRR {method.mrr.toFixed(2)}</span></div>
              <ol>
                {result.top.length ? result.top.slice(0, 3).map((row: any, index: number) => {
                  const relevant = query.relevant.includes(row.id);
                  return <li className={relevant ? "relevant" : ""} key={`${id}-${row.id}`}><b>{index + 1}</b><div><code>{row.id}</code><p>{row.excerpt || "No excerpt returned."}</p></div><strong>{row.score.toFixed(2)}</strong>{relevant ? <em>answer</em> : null}</li>;
                }) : <li className="empty-result"><div><strong>No files returned</strong><p>The natural-language query had no sufficient keyword match.</p></div></li>}
              </ol>
            </article>
          );
        })}
      </div>
      <p className="comparison-note"><strong>How to read the timing:</strong> QMD ran one query at a time. TypeSafe scored all 70 document-question pairs in one parallel batch. QMD indexing took {(experiment.comparison.qmd.index_wall_ms / 1000).toFixed(1)}s and its one-time embedding pass took {(experiment.comparison.qmd.embed_wall_ms / 1000).toFixed(1)}s; those setup costs are not included in query times.</p>
    </section>
  );
}

function Demo({ experiment }: { experiment: Experiment }) {
  const [elapsed, setElapsed] = useState(0);
  const [playing, setPlaying] = useState(false);
  const frame = useRef<number | null>(null);
  const stats = getExperimentStats(experiment);
  const maxReveal = getReplayDuration(experiment);

  const replay = useCallback(() => {
    if (frame.current) cancelAnimationFrame(frame.current);
    setElapsed(0);
    setPlaying(true);
    const started = performance.now();
    const tick = () => {
      const next = performance.now() - started;
      if (next < maxReveal) {
        setElapsed(next);
        frame.current = requestAnimationFrame(tick);
      } else {
        setElapsed(maxReveal);
        setPlaying(false);
        frame.current = null;
      }
    };
    frame.current = requestAnimationFrame(tick);
  }, [maxReveal]);

  useEffect(() => {
    replay();
    const replayWhenVisible = () => { if (document.visibilityState === "visible") replay(); };
    document.addEventListener("visibilitychange", replayWhenVisible);
    return () => {
      document.removeEventListener("visibilitychange", replayWhenVisible);
      if (frame.current) cancelAnimationFrame(frame.current);
    };
  }, [experiment.id, replay]);

  return (
    <section className="demo" aria-labelledby={`${experiment.id}-title`}>
      <div className="demo-intro">
        <div>
          <p className="eyebrow">{COPY[experiment.id].eyebrow}</p>
          <h2 id={`${experiment.id}-title`}>{COPY[experiment.id].title}</h2>
          <p className="thesis">{COPY[experiment.id].thesis}</p>
        </div>
        {experiment.id === "judge-grid" ? (
          <div className="metric-line">
            <Metric label="TypeSafe" value={`${experiment.typesafe.mean_wall_ms.toFixed(0)} ms`} sub={`${experiment.typesafe.repeats}-run mean`} />
            <Metric label="GPT-5.4 mini" value={`${experiment.external.mean_wall_ms.toFixed(0)} ms`} sub={`${experiment.external.repeats}-run mean`} />
            <Metric label="measured speedup" value={`${(experiment.external.mean_wall_ms / experiment.typesafe.mean_wall_ms).toFixed(1)}×`} sub="same 6 × 6 rubric" />
          </div>
        ) : experiment.id === "agent-navigation" ? (
          <div className="metric-line">
            <Metric label="manual search" value={`${(experiment.trials[0].wall_ms / 1000).toFixed(1)}s`} sub={`${experiment.trials[0].files_opened} files opened`} />
            <Metric label="TypeSafe-guided" value={`${(experiment.trials[1].wall_ms / 1000).toFixed(1)}s`} sub={`${experiment.trials[1].files_opened} files opened`} />
            <Metric label="measured speedup" value={`${(experiment.trials[0].wall_ms / experiment.trials[1].wall_ms).toFixed(1)}×`} sub="same Claude task" />
          </div>
        ) : (
          <div className="metric-line">
            <Metric label="wall time" value={`${stats.wall.toFixed(0)} ms`} sub="live measurement" />
            <Metric label="judgments" value={String(stats.judgments)} sub={`${stats.calls} parallel calls`} />
            <Metric label="TypeSafe cost" value={money(stats.cost)} sub="at $0.042 / 1M input" />
          </div>
        )}
      </div>

      <div className="replay-shell">
        <ReplayHeader experiment={experiment} playing={playing} elapsed={elapsed} duration={maxReveal} onReplay={replay} />
        <div className="replay-stage">
          {experiment.kind === "retrieval" ? <RetrievalGrid experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.id === "agent-navigation" ? <AgentTrajectory experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.id === "judge-grid" ? <JudgeGrid experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.id === "action-firewall" ? <FirewallRows experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.id === "vc-diligence" ? <VCRows experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.id === "ai-checker" ? <AICheckerGrid experiment={experiment} elapsed={elapsed} /> : null}
          {experiment.kind === "decision-matrix" ? <DecisionMatrix experiment={experiment} elapsed={elapsed} /> : null}
        </div>
      </div>

      {experiment.kind === "retrieval" ? <RetrievalResults experiment={experiment} elapsed={elapsed} /> : null}
      {experiment.id === "company-brain" ? <CompanyBrainComparison experiment={experiment} /> : null}
      {experiment.id === "action-firewall" || experiment.id === "vc-diligence" ? (
        <ProgressiveAccuracyStrip experiment={experiment} elapsed={elapsed} />
      ) : null}
      {experiment.id === "ai-checker" ? <AICheckerResults experiment={experiment} elapsed={elapsed} /> : null}
      {experiment.kind === "decision-matrix" ? <DecisionResults experiment={experiment} elapsed={elapsed} /> : null}

      <div className="analysis-note"><span>Readout</span><p>{COPY[experiment.id].take}</p></div>

      <SetupPanel experiment={experiment} />
    </section>
  );
}

export default function ExperimentLab({ data }: { data: Payload }) {
  const [selectedId, setSelectedId] = useState(data.experiments[0].id);
  const selected = data.experiments.find((experiment) => experiment.id === selectedId) ?? data.experiments[0];
  const selectedIndex = data.experiments.findIndex((experiment) => experiment.id === selected.id);
  const nextExperiment = data.experiments[(selectedIndex + 1) % data.experiments.length];
  const goToNextExperiment = () => {
    setSelectedId(nextExperiment.id);
    requestAnimationFrame(() => document.querySelector(".demo")?.scrollIntoView({ behavior: "smooth", block: "start" }));
  };
  const totals = useMemo(() => {
    let calls = 0;
    let judgments = 0;
    let cost = 0;
    for (const experiment of data.experiments) {
      if (experiment.id === "judge-grid") {
        calls += experiment.typesafe.measured.calls;
        judgments += experiment.typesafe.measured.judgments;
        cost += experiment.typesafe.measured.usage.estimated_cost_usd;
      } else if (experiment.id === "agent-navigation") {
        calls += experiment.typesafe.measured.calls;
        judgments += experiment.typesafe.measured.judgments;
        cost += experiment.typesafe.measured.usage.estimated_cost_usd;
      } else {
        calls += experiment.measured.calls;
        judgments += experiment.measured.judgments;
        cost += experiment.measured.usage.estimated_cost_usd;
      }
    }
    return { calls, judgments, cost };
  }, [data.experiments]);

  return (
    <main>
      <header className="site-header">
        <a className="wordmark" href="#top"><span>TYPE</span>SAFE <i>LAB/11</i></a>
        <nav aria-label="Experiment navigation">
          {data.experiments.map((experiment, index) => (
            <button key={experiment.id} className={selectedId === experiment.id ? "selected" : ""} onClick={() => setSelectedId(experiment.id)}>
              <span>{String(index + 1).padStart(2, "0")}</span>{COPY[experiment.id].label}
            </button>
          ))}
        </nav>
        <a className="docs-link" href="https://ts-docs.mintlify.site/introduction" target="_blank" rel="noreferrer">API docs ↗</a>
      </header>

      <section className="hero" id="top">
        <div className="hero-kicker"><span>MEASURED 2026.08.28</span><i /> <span>PROBABILITIES, NOT PROSE</span></div>
        <h1>What if judgment<br />were <em>parallel?</em></h1>
        <p>Eleven practical experiments with a model that returns probabilities instead of prose. Find an answer, watch an agent navigate, compare retrieval methods, sort an inbox, or ask 100 synthetic personas which ad they would click.</p>
        <div className="hero-stats">
          <div><strong>{totals.judgments}</strong><span>typed judgments</span></div>
          <div><strong>{totals.calls}</strong><span>live API calls</span></div>
          <div><strong>{money(totals.cost)}</strong><span>estimated TypeSafe spend</span></div>
        </div>
      </section>

      <section className="experiment-picker" aria-label="Choose an experiment">
        {data.experiments.map((experiment, index) => {
          const stats = getExperimentStats(experiment);
          return (
            <button key={experiment.id} onClick={() => setSelectedId(experiment.id)} className={selectedId === experiment.id ? "selected" : ""} aria-pressed={selectedId === experiment.id}>
              <span className="picker-index">{String(index + 1).padStart(2, "0")}</span>
              <strong>{COPY[experiment.id].label}</strong>
              <small>{stats.judgments} judgments / {stats.wall.toFixed(0)} ms</small>
            </button>
          );
        })}
      </section>

      <Demo key={selected.id} experiment={selected} />

      <button className="next-experiment" type="button" onClick={goToNextExperiment}>
        <span>Continue to experiment {String((selectedIndex + 1) % data.experiments.length + 1).padStart(2, "0")}</span>
        <strong>{COPY[nextExperiment.id].label}</strong>
        <i aria-hidden="true">→</i>
      </button>

      <section className="method">
        <div>
          <p className="eyebrow">how the engine works</p>
          <h2>One item. Many small questions. One useful action.</h2>
        </div>
        <ol>
          <li><span>01</span><div><strong>Give it an item</strong><p>Send a code file, email, customer message, article, or other piece of text.</p></div></li>
          <li><span>02</span><div><strong>Choose the answer shape</strong><p>Use Noul for yes/no probability, Choice for a classification, or Score for an ordered rubric.</p></div></li>
          <li><span>03</span><div><strong>Get every judgment together</strong><p>TypeSafe evaluates the questions in parallel and returns probabilities, selected classes, scores, and confidence instead of prose.</p></div></li>
          <li><span>04</span><div><strong>Turn scores into an action</strong><p>Ordinary code ranks the results, applies thresholds, and sends uncertain cases to a person.</p></div></li>
        </ol>
      </section>

      <section className="audit-downloads" aria-labelledby="downloads-title">
        <div>
          <p className="eyebrow">reproduce the lab</p>
          <h2 id="downloads-title">Explore every experiment in detail.</h2>
          <p>Each experiment includes its inputs, exact typed questions, answers, timings, and decision logic. Use the notebook for a guided walkthrough or download the complete source to run the lab yourself.</p>
        </div>
        <div className="download-grid">
          <a href="/downloads/typesafe-lab.ipynb" download><span>Jupyter notebook</span><strong>Read and rerun the lab</strong><i>.ipynb ↘</i></a>
          <a href="/downloads/experiments.json" download><span>Results data</span><strong>Every score and timing</strong><i>.json ↘</i></a>
          <a href="/downloads/experiment-report.md" download><span>Run report</span><strong>Results and limitations</strong><i>.md ↘</i></a>
          <a href="/downloads/typesafe-lab-source.zip" download><span>Complete source</span><strong>Scripts, fixtures, notebook</strong><i>.zip ↘</i></a>
        </div>
      </section>

      <footer>
        <div><span className="status-light" /> Performance figures come from the measured run completed {new Date(data.generated_at).toLocaleString("en-US", { timeZone: "America/New_York", dateStyle: "medium", timeStyle: "short" })} ET.</div>
        <div>Built from <a href="https://ts-docs.mintlify.site/cookbooks/consistency_noul_cookbook" target="_blank" rel="noreferrer">TypeSafe’s self-consistency cookbook ↗</a></div>
      </footer>
    </main>
  );
}
