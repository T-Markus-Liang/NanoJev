import type { Metadata } from "next";
import ExperimentLab from "./ExperimentLab";
import experimentData from "../public/experiments.json";

export const metadata: Metadata = {
  title: "TypeSafe // Parallel Judgment Lab",
  description: "Eleven measured TypeSafe experiments with inspectable setups, saved trajectories, retrieval comparisons, and downloadable code and notebooks.",
};

export default function Home() {
  return <ExperimentLab data={experimentData} />;
}
