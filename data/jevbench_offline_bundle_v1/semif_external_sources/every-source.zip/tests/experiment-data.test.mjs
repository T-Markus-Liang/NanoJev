import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const data = JSON.parse(await readFile(new URL("../public/experiments.json", import.meta.url), "utf8"));

test("ships eleven completed experiments", () => {
  assert.deepEqual(data.experiments.map((experiment) => experiment.id), [
    "code-rag",
    "agent-navigation",
    "company-brain",
    "judge-grid",
    "action-firewall",
    "vc-diligence",
    "ai-checker",
    "customer-voice",
    "ceo-radar",
    "inbox-urgency",
    "persona-panel",
  ]);
});

test("agent navigation compares equivalent Claude runs with a measured TypeSafe tool trace", () => {
  const experiment = data.experiments.find((item) => item.id === "agent-navigation");
  assert.equal(experiment.kind, "agent-trajectory");
  assert.equal(experiment.task.id, "refresh-token-replay");
  assert.ok(experiment.corpus.files >= 24);
  assert.equal(experiment.trials.length, 2);
  const baseline = experiment.trials.find((trial) => trial.id === "manual-search");
  const assisted = experiment.trials.find((trial) => trial.id === "typesafe-rag");
  assert.equal(baseline.correct, true);
  assert.equal(assisted.correct, true);
  assert.ok(assisted.events.some((event) => event.kind === "typesafe_search"));
  assert.ok(assisted.files_opened <= baseline.files_opened);
  assert.ok(experiment.typesafe.measured.wall_ms > 0);
  assert.ok(experiment.typesafe.ranking[0].score > experiment.typesafe.ranking[1].score);
});

test("company brain includes measured QMD keyword and semantic rankings", () => {
  const experiment = data.experiments.find((item) => item.id === "company-brain");
  assert.equal(experiment.comparison.qmd.version, "2.8.3");
  for (const method of ["keyword", "semantic", "typesafe"]) {
    assert.ok(experiment.comparison.methods[method].wall_ms > 0);
    assert.equal(experiment.comparison.methods[method].queries.length, experiment.grid.length);
  }
  assert.ok(experiment.comparison.methods.keyword.queries.some((query) => query.top.length === 0));
  assert.ok(experiment.comparison.methods.semantic.queries.every((query) => query.top.length >= 1));
  assert.ok(experiment.comparison.methods.typesafe.queries.every((query) => query.top.length >= 3));
  assert.ok(experiment.comparison.methods.semantic.implementation.includes("QMD"));
  assert.ok(experiment.comparison.methods.keyword.implementation.includes("QMD"));
});

test("four accessible application experiments contain live rows and exact questions", () => {
  for (const id of ["customer-voice", "ceo-radar", "inbox-urgency", "persona-panel"]) {
    const experiment = data.experiments.find((item) => item.id === id);
    assert.equal(experiment.kind, "decision-matrix");
    assert.ok(experiment.rows.length >= 18);
    assert.ok(Object.keys(experiment.questions).length >= 1);
    assert.equal(experiment.measured.judgments, experiment.rows.length * Object.keys(experiment.questions).length);
  }
  const ceo = data.experiments.find((item) => item.id === "ceo-radar");
  assert.equal(ceo.questions.decision_owner.type, "choice");
  assert.ok(ceo.rows.every((row) => row.document.includes("SYNTHETIC SLACK THREAD") && row.messages.length >= 3));
  assert.ok(ceo.rows.every((row) => row.typed_answers.decision_owner.type === "choice"));

  const inbox = data.experiments.find((item) => item.id === "inbox-urgency");
  assert.equal(inbox.metrics.accuracy, 1);
  assert.equal(inbox.questions.reply_action.type, "choice");
  assert.equal(inbox.questions.urgency.type, "score");
  assert.ok(inbox.rows.every((row) => row.document.includes("SUBJECT:") && row.document.includes("BODY:")));
  assert.ok(inbox.rows.every((row) => row.typed_answers.reply_action.type === "choice" && row.typed_answers.urgency.type === "score"));

  const personas = data.experiments.find((item) => item.id === "persona-panel");
  assert.equal(personas.rows.length, 100);
  assert.equal(personas.questions.ad_choice.type, "choice");
  assert.ok(Math.abs(Object.values(personas.metrics.averages).reduce((sum, value) => sum + value, 0) - 1) < 0.01);
  assert.ok(personas.rows.every((row) => Math.abs(Object.values(row.choice_probabilities).reduce((sum, value) => sum + value, 0) - 1) < 0.01));
});

test("AI checker uses the full public archive and a controlled paired test", () => {
  const checker = data.experiments.find((item) => item.id === "ai-checker");
  assert.equal(checker.source.public_posts, 27);
  assert.equal(Object.keys(checker.questions).length, 21);
  assert.equal(checker.metrics.pairs.length, 10);
  assert.equal(checker.metrics.pairwise_separation_rate, 1);
  assert.match(checker.methodology.caveat, /not authorship or provenance/i);
});

test("retrieval experiments include measured timing and ground-truth metrics", () => {
  for (const id of ["code-rag", "company-brain"]) {
    const experiment = data.experiments.find((item) => item.id === id);
    assert.ok(experiment.measured.wall_ms > 0);
    assert.ok(experiment.measured.judgments > 0);
    assert.ok(experiment.metrics.recall_at_3 >= 0.8);
    assert.ok(experiment.metrics.queries.every((query) => query.relevant.length > 0));
    assert.equal(experiment.grid.length, experiment.metrics.queries.length);
    for (const row of experiment.grid) {
      assert.equal(row.label, row.question);
      assert.match(row.question, /^(Does|Is) this (file|document)\b/);
      assert.notEqual(row.query, row.question);
    }
  }
  const companyBrain = data.experiments.find((item) => item.id === "company-brain");
  assert.ok(companyBrain.grid.every((row) => row.question.startsWith("Does this document answer the question:")));
});

test("judge comparison uses live repeated runs and is faster than the external judge", () => {
  const judge = data.experiments.find((item) => item.id === "judge-grid");
  assert.equal(judge.external.status, "measured");
  assert.ok(judge.typesafe.repeats >= 5);
  assert.ok(judge.external.repeats >= 3);
  assert.ok(judge.typesafe.mean_wall_ms < judge.external.mean_wall_ms);
  assert.equal(judge.typesafe.replay.length, 36);
});

test("every replay event is anchored to a measured call completion", () => {
  for (const experiment of data.experiments) {
    if (experiment.id === "agent-navigation") {
      for (const trial of experiment.trials) {
        assert.ok(Math.max(...trial.events.map((event) => event.completed_ms ?? event.at_ms)) <= trial.wall_ms);
      }
      assert.ok(Math.max(...experiment.typesafe.ranking.map((row) => row.latency_ms)) <= experiment.typesafe.measured.wall_ms + 1);
      continue;
    }
    if (experiment.id === "judge-grid") {
      for (const document of experiment.documents) {
        const rowTimes = new Set(experiment.typesafe.replay.filter((cell) => cell.output === document.id).map((cell) => cell.reveal_ms));
        assert.equal(rowTimes.size, 1, `${document.id} should arrive as one completed call`);
      }
      assert.ok(Math.max(...experiment.typesafe.replay.map((cell) => cell.reveal_ms)) <= Math.max(experiment.typesafe.mean_wall_ms, 200));
      continue;
    }

    if (experiment.kind === "retrieval") {
      for (const [index, document] of experiment.documents.entries()) {
        const cellTimes = new Set(experiment.grid.flatMap((row) => row.cells.filter((cell) => cell.document === document.id).map((cell) => cell.reveal_ms)));
        assert.deepEqual([...cellTimes], [experiment.measured.per_call_ms[index]]);
      }
    } else if (experiment.measured.per_call_ms) {
      assert.deepEqual(experiment.rows.map((row) => row.reveal_ms), experiment.measured.per_call_ms);
    }

    const reveals = experiment.kind === "retrieval"
      ? experiment.grid.flatMap((row) => row.cells.map((cell) => cell.reveal_ms))
      : experiment.rows.map((row) => row.reveal_ms);
    assert.ok(Math.max(...reveals) <= experiment.measured.wall_ms + 1, `${experiment.id} reveals after measured wall time`);
  }
});

test("action routing matches labels and investment ranking uses a shared memo", () => {
  const firewall = data.experiments.find((item) => item.id === "action-firewall");
  assert.equal(firewall.measured.accuracy, 1);
  assert.ok(firewall.rows.every((row) => row.decision === row.expected));

  const vc = data.experiments.find((item) => item.id === "vc-diligence");
  assert.ok(vc.context.text.length > 1_500);
  assert.match(vc.questions.should_invest, /should Signal Ridge Ventures pursue an investment/i);
  assert.equal(vc.ranking_signal, "should_invest");
  assert.ok(vc.rows.every((row) => typeof row.signals.should_invest === "number"));
  assert.ok(vc.measured.accuracy >= 0.75);
  assert.ok(vc.rows[0].composite > vc.rows.at(-1).composite);
});

test("public replay data does not contain credentials", async () => {
  const serialized = JSON.stringify(data);
  assert.equal(serialized.includes("apikey_"), false);
  const page = await readFile(new URL("../app/ExperimentLab.tsx", import.meta.url), "utf8");
  assert.equal(page.includes("apikey_"), false);
});

test("ships auditable notebook, manifest, and source downloads", async () => {
  const notebook = JSON.parse(await readFile(new URL("../public/downloads/typesafe-lab.ipynb", import.meta.url), "utf8"));
  const manifest = JSON.parse(await readFile(new URL("../public/downloads/RUN_MANIFEST.json", import.meta.url), "utf8"));
  const exported = JSON.parse(await readFile(new URL("../public/downloads/experiments.json", import.meta.url), "utf8"));
  const bundle = await stat(new URL("../public/downloads/typesafe-lab-source.zip", import.meta.url));
  assert.equal(notebook.nbformat, 4);
  assert.equal(manifest.experiments.length, 11);
  const expectedJudgments = data.experiments.reduce((sum, experiment) => {
    if (["judge-grid", "agent-navigation"].includes(experiment.id)) return sum + experiment.typesafe.measured.judgments;
    return sum + experiment.measured.judgments;
  }, 0);
  assert.equal(manifest.totals.judgments, expectedJudgments);
  assert.equal(exported.generated_at, data.generated_at);
  assert.ok(bundle.size > 100_000);
});
