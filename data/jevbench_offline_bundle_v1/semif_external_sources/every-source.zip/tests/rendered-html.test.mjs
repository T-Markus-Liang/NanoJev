import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the completed experiment lab", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  const html = await response.text();
  assert.match(html, /<title>TypeSafe \/\/ Parallel Judgment Lab<\/title>/i);
  assert.match(html, /What if judgment/);
  assert.match(html, /typed judgments/);
  assert.match(html, /Replay Code repository RAG/);
  assert.match(html, /Code repository RAG/);
  assert.match(html, /0\/8 calls returned/);
  assert.match(html, /0\/48 judgments/);
  assert.match(html, /1× saved timing/);
  assert.match(html, /TypeSafe Recall@1<\/span><strong>—/);
  assert.doesNotMatch(html, /codex-preview|react-loading-skeleton|Your site is taking shape/i);
});

test("includes all eleven selectable experiment labels and reproducibility downloads", async () => {
  const html = await (await render()).text();
  for (const label of ["Code answer finder", "Agent navigation race", "Policy answer finder", "Reply quality checker", "Risky-action stoplight", "Startup pitch sorter", "AI writing checker", "Customer mood triage", "CEO decision radar", "Inbox reply queue", "100-person ad panel"]) {
    assert.match(html, new RegExp(label));
  }
  assert.match(html, /Manual file search/);
  assert.match(html, /TypeSafe-guided search/);
  assert.match(html, /aria-pressed="true"/);
  assert.match(html, /aria-label="Experiment navigation"/);
  assert.match(html, /Jupyter notebook/);
  assert.match(html, /typesafe-lab-source\.zip/);
  assert.doesNotMatch(html, /Yes, these were actually run|the actual test setup|explained for normal people/i);
});

test("puts the interactive experiment before methodology and downloads", async () => {
  const html = await (await render()).text();
  const demo = html.indexOf('class="experiment-picker"');
  const method = html.indexOf('class="method"');
  const downloads = html.indexOf('class="audit-downloads"');
  assert.ok(demo > -1 && method > demo && downloads > method);
  assert.ok(html.indexOf('class="replay-shell"') < html.indexOf('class="setup-panel"'));
  assert.ok(html.indexOf('class="next-experiment"') < method);
  assert.match(html, /One item\. Many small questions\. One useful action\./);
});
