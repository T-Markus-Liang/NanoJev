# TypeSafe Parallel Judgment Lab

This bundle contains the runnable source, exact experiment inputs, recorded API results, run manifest, and Jupyter notebook for all 11 experiments.

## Start with the notebook

Open `notebooks/TypeSafe_Parallel_Judgment_Lab.ipynb`. It summarizes the saved run, prints every question, inspects row-level Noul, Choice, and Score answers, shows a minimal live API call, and lists the complete rerun commands.

## Experiment files

- `public/experiments.json`: the row-level typed answers and timings replayed by the website
- `experiments/RUN_MANIFEST.json`: run totals, commands, and SHA-256 artifact hashes
- `experiments/REPORT.md`: human-readable results and limitations
- `fixtures/`: exact synthetic corpora, de-identified scenarios, persona matrix, and public-article test inputs

## Rerun

Use Node.js 22 or newer. Set `TYPESAFE_API_KEY`; set `OPENAI_API_KEY` for the external judge comparison and controlled AI-text generation. The agent trajectory also requires the Claude Headless CLI. The company-brain comparison uses QMD 2.8.3 and downloads its local embedding model on first use.

```bash
npm install
node scripts/run-experiments.mjs
node scripts/run-agent-navigation.mjs
node scripts/merge-agent-navigation.mjs
QMD_BIN=qmd node scripts/run-qmd-comparison.mjs
node scripts/run-ai-checker.mjs --reuse
node scripts/run-more-experiments.mjs
node scripts/build-downloads.mjs
```

Customer-support and email inputs are synthetic. Slack-derived decisions are de-identified summaries, not raw messages. The agent race uses one run per condition on a synthetic codebase. The AI checker detects writing patterns, not authorship. Persona scores are hypotheses to validate with real ad clicks.
